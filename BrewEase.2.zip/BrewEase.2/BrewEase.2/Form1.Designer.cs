﻿namespace BrewEase._2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnMain = new Button();
            btnAddOns = new Button();
            btnUtilities = new Button();
            txtBoxSearch = new TextBox();
            btnLogOut = new Button();
            panelList = new Panel();
            panelList2 = new Panel();
            panelList3 = new Panel();
            panelList2.SuspendLayout();
            panelList3.SuspendLayout();
            SuspendLayout();
            // 
            // btnMain
            // 
            btnMain.BackColor = SystemColors.AppWorkspace;
            btnMain.FlatStyle = FlatStyle.Flat;
            btnMain.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMain.Location = new Point(466, 140);
            btnMain.Name = "btnMain";
            btnMain.Size = new Size(139, 38);
            btnMain.TabIndex = 0;
            btnMain.Text = "MAIN";
            btnMain.UseVisualStyleBackColor = false;
            btnMain.Click += btnMain_Click;
            // 
            // btnAddOns
            // 
            btnAddOns.BackColor = SystemColors.AppWorkspace;
            btnAddOns.FlatStyle = FlatStyle.Flat;
            btnAddOns.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddOns.Location = new Point(611, 140);
            btnAddOns.Name = "btnAddOns";
            btnAddOns.Size = new Size(139, 38);
            btnAddOns.TabIndex = 1;
            btnAddOns.Text = "ADD ONS";
            btnAddOns.UseVisualStyleBackColor = false;
            btnAddOns.Click += btnAddOns_Click;
            // 
            // btnUtilities
            // 
            btnUtilities.BackColor = SystemColors.AppWorkspace;
            btnUtilities.FlatStyle = FlatStyle.Flat;
            btnUtilities.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUtilities.Location = new Point(756, 140);
            btnUtilities.Name = "btnUtilities";
            btnUtilities.Size = new Size(139, 38);
            btnUtilities.TabIndex = 2;
            btnUtilities.Text = "UTILITIES";
            btnUtilities.UseVisualStyleBackColor = false;
            btnUtilities.Click += btnUtilities_Click;
            // 
            // txtBoxSearch
            // 
            txtBoxSearch.BackColor = Color.Gainsboro;
            txtBoxSearch.BorderStyle = BorderStyle.None;
            txtBoxSearch.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtBoxSearch.Location = new Point(530, 77);
            txtBoxSearch.Name = "txtBoxSearch";
            txtBoxSearch.Size = new Size(303, 22);
            txtBoxSearch.TabIndex = 4;
            txtBoxSearch.TextChanged += txtBoxSearch_TextChanged;
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.MediumSeaGreen;
            btnLogOut.FlatStyle = FlatStyle.Flat;
            btnLogOut.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogOut.ForeColor = SystemColors.Window;
            btnLogOut.Location = new Point(77, 12);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(87, 33);
            btnLogOut.TabIndex = 5;
            btnLogOut.Text = "Logout";
            btnLogOut.UseVisualStyleBackColor = false;
            btnLogOut.Click += btnLogOut_Click;
            // 
            // panelList
            // 
            panelList.BackColor = SystemColors.ActiveBorder;
            panelList.Location = new Point(0, 0);
            panelList.Name = "panelList";
            panelList.Size = new Size(1111, 549);
            panelList.TabIndex = 6;
            panelList.Paint += panelList_Paint;
            // 
            // panelList2
            // 
            panelList2.BackColor = SystemColors.ActiveBorder;
            panelList2.Controls.Add(panelList);
            panelList2.Location = new Point(0, 0);
            panelList2.Name = "panelList2";
            panelList2.Size = new Size(1111, 549);
            panelList2.TabIndex = 0;
            panelList2.Paint += panelList2_Paint;
            // 
            // panelList3
            // 
            panelList3.BackColor = SystemColors.ActiveBorder;
            panelList3.Controls.Add(panelList2);
            panelList3.Location = new Point(131, 222);
            panelList3.Name = "panelList3";
            panelList3.Size = new Size(1111, 549);
            panelList3.TabIndex = 0;
            panelList3.Paint += panelList3_Paint;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.bg;
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(1270, 783);
            Controls.Add(panelList3);
            Controls.Add(btnLogOut);
            Controls.Add(txtBoxSearch);
            Controls.Add(btnUtilities);
            Controls.Add(btnAddOns);
            Controls.Add(btnMain);
            DoubleBuffered = true;
            Name = "Form1";
            Text = "BigBrew Point of Sale Main";
            Load += Form1_Load;
            panelList2.ResumeLayout(false);
            panelList3.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnMain;
        private Button btnAddOns;
        private Button btnUtilities;
        private TextBox txtBoxSearch;
        private Button btnLogOut;
        private Panel panelList;
        private Panel panelList2;
        private Panel panelList3;
    }
}
