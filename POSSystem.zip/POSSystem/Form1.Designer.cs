﻿namespace POSSystem
{
    partial class POS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(POS));
            this.btnOkinawa = new System.Windows.Forms.Button();
            this.btnDoubleDutch = new System.Windows.Forms.Button();
            this.btnTaro = new System.Windows.Forms.Button();
            this.btnIcedEarlGray = new System.Windows.Forms.Button();
            this.btnWintermelon = new System.Windows.Forms.Button();
            this.btnRedVelvet = new System.Windows.Forms.Button();
            this.btnMatcha = new System.Windows.Forms.Button();
            this.btnDarkChoco = new System.Windows.Forms.Button();
            this.btnChocoKisses = new System.Windows.Forms.Button();
            this.btnCheeseCake = new System.Windows.Forms.Button();
            this.btnHoneyDue = new System.Windows.Forms.Button();
            this.btnBrownSugar = new System.Windows.Forms.Button();
            this.btnStrawberry = new System.Windows.Forms.Button();
            this.btnLychee = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnJasmine = new System.Windows.Forms.Button();
            this.btnAlmond = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnIrish = new System.Windows.Forms.Button();
            this.btnPumpkin = new System.Windows.Forms.Button();
            this.btnAlmondMilk = new System.Windows.Forms.Button();
            this.btnMatchaLatte = new System.Windows.Forms.Button();
            this.btnChocoMint = new System.Windows.Forms.Button();
            this.btnPeanut = new System.Windows.Forms.Button();
            this.btnMaple = new System.Windows.Forms.Button();
            this.btnCoconut = new System.Windows.Forms.Button();
            this.btnHazelnut = new System.Windows.Forms.Button();
            this.btnVanilla = new System.Windows.Forms.Button();
            this.btnMoca = new System.Windows.Forms.Button();
            this.btnMacch = new System.Windows.Forms.Button();
            this.btnChaiLatte = new System.Windows.Forms.Button();
            this.btnLavender = new System.Windows.Forms.Button();
            this.btnCaramel = new System.Windows.Forms.Button();
            this.btnKapeBrusko = new System.Windows.Forms.Button();
            this.btnMilkTea = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.btnMaximize = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnIcedCoffee = new System.Windows.Forms.Button();
            this.btnFruitTea = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnCoconutTea = new System.Windows.Forms.Button();
            this.btnHoneyDew = new System.Windows.Forms.Button();
            this.btnPomegranate = new System.Windows.Forms.Button();
            this.btnDragonFruit = new System.Windows.Forms.Button();
            this.btnLycheeTea = new System.Windows.Forms.Button();
            this.btnApple = new System.Windows.Forms.Button();
            this.btnCherry = new System.Windows.Forms.Button();
            this.btnPineappleTea = new System.Windows.Forms.Button();
            this.btnBlueberry = new System.Windows.Forms.Button();
            this.btnLemonTea = new System.Windows.Forms.Button();
            this.btnStrawberryTea = new System.Windows.Forms.Button();
            this.btnMango = new System.Windows.Forms.Button();
            this.btnCranberry = new System.Windows.Forms.Button();
            this.btnGrapefruit = new System.Windows.Forms.Button();
            this.btnWatermelonTea = new System.Windows.Forms.Button();
            this.btnPeach = new System.Windows.Forms.Button();
            this.btnPraf = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnMachaGreenTea = new System.Windows.Forms.Button();
            this.btnChaiLatteFrappe = new System.Windows.Forms.Button();
            this.btnRedVelvetFrappe = new System.Windows.Forms.Button();
            this.btnBananaMochaFrappe = new System.Windows.Forms.Button();
            this.btnStrawberryFrappe = new System.Windows.Forms.Button();
            this.btnPumpkinSpice = new System.Windows.Forms.Button();
            this.btnToffeeNut = new System.Windows.Forms.Button();
            this.btnPeanutButterFrappe = new System.Windows.Forms.Button();
            this.btnCookiesAndCream = new System.Windows.Forms.Button();
            this.btnChocoloateFrappe = new System.Windows.Forms.Button();
            this.btnCoconutFrappe = new System.Windows.Forms.Button();
            this.btnHazelnutFrappe = new System.Windows.Forms.Button();
            this.btnVanillaFrappe = new System.Windows.Forms.Button();
            this.btnCaramelFrappe = new System.Windows.Forms.Button();
            this.btnMochaFrappe = new System.Windows.Forms.Button();
            this.btnClassicCofee = new System.Windows.Forms.Button();
            this.btnHotBrew = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnClassicMocha = new System.Windows.Forms.Button();
            this.btnChaiLatteHot = new System.Windows.Forms.Button();
            this.btnIrishCreamLatte = new System.Windows.Forms.Button();
            this.btnCoconutMochaLatte = new System.Windows.Forms.Button();
            this.btnAlmondJoy = new System.Windows.Forms.Button();
            this.btnMexicanMocha = new System.Windows.Forms.Button();
            this.btnGingerbreadLatte = new System.Windows.Forms.Button();
            this.btnSaltedCaramelLatte = new System.Windows.Forms.Button();
            this.btnHoneyAlmondLatte = new System.Windows.Forms.Button();
            this.btnToastedMarshmallow = new System.Windows.Forms.Button();
            this.btnCinnamonDolceLatte = new System.Windows.Forms.Button();
            this.btnHazelnutHotBrew = new System.Windows.Forms.Button();
            this.btnLavenderLatteHot = new System.Windows.Forms.Button();
            this.btnBrownSugarOathMilk = new System.Windows.Forms.Button();
            this.btnMaplePecanLatte = new System.Windows.Forms.Button();
            this.btnCaramelMacchiato = new System.Windows.Forms.Button();
            this.btnQtyLess = new System.Windows.Forms.Button();
            this.btnHigh = new System.Windows.Forms.Button();
            this.btnSmall = new System.Windows.Forms.Button();
            this.btnMedium = new System.Windows.Forms.Button();
            this.btnLarge = new System.Windows.Forms.Button();
            this.btnPearl = new System.Windows.Forms.Button();
            this.btnCrystal = new System.Windows.Forms.Button();
            this.btnCreamCheese = new System.Windows.Forms.Button();
            this.btnCoffeeJelly = new System.Windows.Forms.Button();
            this.btnCrushedOreo = new System.Windows.Forms.Button();
            this.btnCreamPuff = new System.Windows.Forms.Button();
            this.btnCakeCheese = new System.Windows.Forms.Button();
            this.btnBlank1 = new System.Windows.Forms.Button();
            this.btnBlank2 = new System.Windows.Forms.Button();
            this.btn25 = new System.Windows.Forms.Button();
            this.btn50 = new System.Windows.Forms.Button();
            this.btn75 = new System.Windows.Forms.Button();
            this.btn100 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnDelete1 = new System.Windows.Forms.Button();
            this.lblItem1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnProceedPayment1 = new System.Windows.Forms.Button();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.btnConfirm1 = new System.Windows.Forms.Button();
            this.btnCancel1 = new System.Windows.Forms.Button();
            this.lblQty = new System.Windows.Forms.Label();
            this.lblSummary = new System.Windows.Forms.Label();
            this.btnPOS = new System.Windows.Forms.Button();
            this.btnIMS = new System.Windows.Forms.Button();
            this.btnCUS = new System.Windows.Forms.Button();
            this.btnREP = new System.Windows.Forms.Button();
            this.btnADM = new System.Windows.Forms.Button();
            this.btnSET = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnCancelPayment = new System.Windows.Forms.Button();
            this.btnCashless = new System.Windows.Forms.Button();
            this.btnCash = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnConfirmPayment4 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCancel2 = new System.Windows.Forms.Button();
            this.btnConfirm2 = new System.Windows.Forms.Button();
            this.txtExactAmount = new System.Windows.Forms.TextBox();
            this.btn1000Pesos = new System.Windows.Forms.Button();
            this.btn500Pesos = new System.Windows.Forms.Button();
            this.btn200Pesos = new System.Windows.Forms.Button();
            this.btn100Pesos = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnCancelPayment3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnMasterCard = new System.Windows.Forms.Button();
            this.btnPaypal = new System.Windows.Forms.Button();
            this.btnPaymaya = new System.Windows.Forms.Button();
            this.btnGcash = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.AdminPanel = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel9.SuspendLayout();
            this.AdminPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOkinawa
            // 
            this.btnOkinawa.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOkinawa.BackgroundImage")));
            this.btnOkinawa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnOkinawa.Location = new System.Drawing.Point(32, 16);
            this.btnOkinawa.Name = "btnOkinawa";
            this.btnOkinawa.Size = new System.Drawing.Size(140, 160);
            this.btnOkinawa.TabIndex = 0;
            this.btnOkinawa.UseVisualStyleBackColor = true;
            this.btnOkinawa.Click += new System.EventHandler(this.btnOkinawa_Click);
            // 
            // btnDoubleDutch
            // 
            this.btnDoubleDutch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDoubleDutch.BackgroundImage")));
            this.btnDoubleDutch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDoubleDutch.Location = new System.Drawing.Point(32, 192);
            this.btnDoubleDutch.Name = "btnDoubleDutch";
            this.btnDoubleDutch.Size = new System.Drawing.Size(140, 157);
            this.btnDoubleDutch.TabIndex = 1;
            this.btnDoubleDutch.UseVisualStyleBackColor = true;
            this.btnDoubleDutch.Click += new System.EventHandler(this.btnDoubleDutch_Click);
            // 
            // btnTaro
            // 
            this.btnTaro.BackColor = System.Drawing.Color.Transparent;
            this.btnTaro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTaro.BackgroundImage")));
            this.btnTaro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTaro.Location = new System.Drawing.Point(30, 365);
            this.btnTaro.Name = "btnTaro";
            this.btnTaro.Size = new System.Drawing.Size(139, 156);
            this.btnTaro.TabIndex = 2;
            this.btnTaro.UseVisualStyleBackColor = false;
            this.btnTaro.Click += new System.EventHandler(this.btnTaro_Click);
            // 
            // btnIcedEarlGray
            // 
            this.btnIcedEarlGray.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnIcedEarlGray.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnIcedEarlGray.BackgroundImage")));
            this.btnIcedEarlGray.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnIcedEarlGray.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.btnIcedEarlGray.Location = new System.Drawing.Point(33, 539);
            this.btnIcedEarlGray.Name = "btnIcedEarlGray";
            this.btnIcedEarlGray.Size = new System.Drawing.Size(139, 156);
            this.btnIcedEarlGray.TabIndex = 3;
            this.btnIcedEarlGray.UseVisualStyleBackColor = false;
            this.btnIcedEarlGray.Click += new System.EventHandler(this.btnIcedEarlGray_Click);
            // 
            // btnWintermelon
            // 
            this.btnWintermelon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWintermelon.BackgroundImage")));
            this.btnWintermelon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnWintermelon.Location = new System.Drawing.Point(195, 19);
            this.btnWintermelon.Name = "btnWintermelon";
            this.btnWintermelon.Size = new System.Drawing.Size(139, 160);
            this.btnWintermelon.TabIndex = 4;
            this.btnWintermelon.UseVisualStyleBackColor = true;
            this.btnWintermelon.Click += new System.EventHandler(this.btnWintermelon_Click);
            // 
            // btnRedVelvet
            // 
            this.btnRedVelvet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRedVelvet.BackgroundImage")));
            this.btnRedVelvet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRedVelvet.Location = new System.Drawing.Point(351, 19);
            this.btnRedVelvet.Name = "btnRedVelvet";
            this.btnRedVelvet.Size = new System.Drawing.Size(139, 160);
            this.btnRedVelvet.TabIndex = 5;
            this.btnRedVelvet.UseVisualStyleBackColor = true;
            this.btnRedVelvet.Click += new System.EventHandler(this.btnRedVelvet_Click);
            // 
            // btnMatcha
            // 
            this.btnMatcha.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMatcha.BackgroundImage")));
            this.btnMatcha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMatcha.Location = new System.Drawing.Point(509, 19);
            this.btnMatcha.Name = "btnMatcha";
            this.btnMatcha.Size = new System.Drawing.Size(139, 157);
            this.btnMatcha.TabIndex = 6;
            this.btnMatcha.UseVisualStyleBackColor = true;
            this.btnMatcha.Click += new System.EventHandler(this.btnMatcha_Click);
            // 
            // btnDarkChoco
            // 
            this.btnDarkChoco.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDarkChoco.BackgroundImage")));
            this.btnDarkChoco.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDarkChoco.Location = new System.Drawing.Point(195, 192);
            this.btnDarkChoco.Name = "btnDarkChoco";
            this.btnDarkChoco.Size = new System.Drawing.Size(139, 157);
            this.btnDarkChoco.TabIndex = 7;
            this.btnDarkChoco.UseVisualStyleBackColor = true;
            this.btnDarkChoco.Click += new System.EventHandler(this.btnDarkChoco_Click);
            // 
            // btnChocoKisses
            // 
            this.btnChocoKisses.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChocoKisses.BackgroundImage")));
            this.btnChocoKisses.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnChocoKisses.Location = new System.Drawing.Point(351, 192);
            this.btnChocoKisses.Name = "btnChocoKisses";
            this.btnChocoKisses.Size = new System.Drawing.Size(139, 157);
            this.btnChocoKisses.TabIndex = 8;
            this.btnChocoKisses.UseVisualStyleBackColor = true;
            this.btnChocoKisses.Click += new System.EventHandler(this.btnChocoKisses_Click);
            // 
            // btnCheeseCake
            // 
            this.btnCheeseCake.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCheeseCake.BackgroundImage")));
            this.btnCheeseCake.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCheeseCake.Location = new System.Drawing.Point(509, 192);
            this.btnCheeseCake.Name = "btnCheeseCake";
            this.btnCheeseCake.Size = new System.Drawing.Size(139, 157);
            this.btnCheeseCake.TabIndex = 9;
            this.btnCheeseCake.UseVisualStyleBackColor = true;
            this.btnCheeseCake.Click += new System.EventHandler(this.btnCheeseCake_Click);
            // 
            // btnHoneyDue
            // 
            this.btnHoneyDue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnHoneyDue.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHoneyDue.BackgroundImage")));
            this.btnHoneyDue.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnHoneyDue.Location = new System.Drawing.Point(187, 365);
            this.btnHoneyDue.Name = "btnHoneyDue";
            this.btnHoneyDue.Size = new System.Drawing.Size(139, 156);
            this.btnHoneyDue.TabIndex = 10;
            this.btnHoneyDue.UseVisualStyleBackColor = false;
            this.btnHoneyDue.Click += new System.EventHandler(this.btnHoneyDue_Click);
            // 
            // btnBrownSugar
            // 
            this.btnBrownSugar.BackColor = System.Drawing.Color.Transparent;
            this.btnBrownSugar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrownSugar.BackgroundImage")));
            this.btnBrownSugar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnBrownSugar.Location = new System.Drawing.Point(351, 365);
            this.btnBrownSugar.Name = "btnBrownSugar";
            this.btnBrownSugar.Size = new System.Drawing.Size(139, 156);
            this.btnBrownSugar.TabIndex = 11;
            this.btnBrownSugar.UseVisualStyleBackColor = false;
            this.btnBrownSugar.Click += new System.EventHandler(this.btnBrownSugar_Click);
            // 
            // btnStrawberry
            // 
            this.btnStrawberry.BackColor = System.Drawing.Color.Transparent;
            this.btnStrawberry.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStrawberry.BackgroundImage")));
            this.btnStrawberry.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnStrawberry.Location = new System.Drawing.Point(509, 365);
            this.btnStrawberry.Name = "btnStrawberry";
            this.btnStrawberry.Size = new System.Drawing.Size(139, 156);
            this.btnStrawberry.TabIndex = 12;
            this.btnStrawberry.UseVisualStyleBackColor = false;
            this.btnStrawberry.Click += new System.EventHandler(this.btnStrawberry_Click);
            // 
            // btnLychee
            // 
            this.btnLychee.BackColor = System.Drawing.Color.Transparent;
            this.btnLychee.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLychee.BackgroundImage")));
            this.btnLychee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLychee.Location = new System.Drawing.Point(187, 539);
            this.btnLychee.Name = "btnLychee";
            this.btnLychee.Size = new System.Drawing.Size(139, 156);
            this.btnLychee.TabIndex = 13;
            this.btnLychee.UseVisualStyleBackColor = false;
            this.btnLychee.Click += new System.EventHandler(this.btnLychee_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.btnChocoKisses);
            this.panel1.Controls.Add(this.btnRedVelvet);
            this.panel1.Controls.Add(this.btnDarkChoco);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnWintermelon);
            this.panel1.Controls.Add(this.btnJasmine);
            this.panel1.Controls.Add(this.btnAlmond);
            this.panel1.Controls.Add(this.btnLychee);
            this.panel1.Controls.Add(this.btnStrawberry);
            this.panel1.Controls.Add(this.btnBrownSugar);
            this.panel1.Controls.Add(this.btnHoneyDue);
            this.panel1.Controls.Add(this.btnCheeseCake);
            this.panel1.Controls.Add(this.btnMatcha);
            this.panel1.Controls.Add(this.btnIcedEarlGray);
            this.panel1.Controls.Add(this.btnTaro);
            this.panel1.Controls.Add(this.btnDoubleDutch);
            this.panel1.Controls.Add(this.btnOkinawa);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(150, 219);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(698, 541);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(191, 497);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 20);
            this.label2.TabIndex = 17;
            this.label2.Text = "    Honey Due   ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 501);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 20);
            this.label1.TabIndex = 16;
            this.label1.Text = "         Taro         ";
            // 
            // btnJasmine
            // 
            this.btnJasmine.BackColor = System.Drawing.Color.Transparent;
            this.btnJasmine.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnJasmine.BackgroundImage")));
            this.btnJasmine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnJasmine.Location = new System.Drawing.Point(509, 539);
            this.btnJasmine.Name = "btnJasmine";
            this.btnJasmine.Size = new System.Drawing.Size(139, 156);
            this.btnJasmine.TabIndex = 15;
            this.btnJasmine.UseVisualStyleBackColor = false;
            this.btnJasmine.Click += new System.EventHandler(this.btnJasmine_Click);
            // 
            // btnAlmond
            // 
            this.btnAlmond.BackColor = System.Drawing.Color.Transparent;
            this.btnAlmond.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAlmond.BackgroundImage")));
            this.btnAlmond.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAlmond.Location = new System.Drawing.Point(351, 539);
            this.btnAlmond.Name = "btnAlmond";
            this.btnAlmond.Size = new System.Drawing.Size(139, 156);
            this.btnAlmond.TabIndex = 14;
            this.btnAlmond.UseVisualStyleBackColor = false;
            this.btnAlmond.Click += new System.EventHandler(this.btnAlmond_Click);
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.btnIrish);
            this.panel2.Controls.Add(this.btnPumpkin);
            this.panel2.Controls.Add(this.btnAlmondMilk);
            this.panel2.Controls.Add(this.btnMatchaLatte);
            this.panel2.Controls.Add(this.btnChocoMint);
            this.panel2.Controls.Add(this.btnPeanut);
            this.panel2.Controls.Add(this.btnMaple);
            this.panel2.Controls.Add(this.btnCoconut);
            this.panel2.Controls.Add(this.btnHazelnut);
            this.panel2.Controls.Add(this.btnVanilla);
            this.panel2.Controls.Add(this.btnMoca);
            this.panel2.Controls.Add(this.btnMacch);
            this.panel2.Controls.Add(this.btnChaiLatte);
            this.panel2.Controls.Add(this.btnLavender);
            this.panel2.Controls.Add(this.btnCaramel);
            this.panel2.Controls.Add(this.btnKapeBrusko);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(698, 542);
            this.panel2.TabIndex = 18;
            // 
            // btnIrish
            // 
            this.btnIrish.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnIrish.BackgroundImage")));
            this.btnIrish.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIrish.Location = new System.Drawing.Point(509, 547);
            this.btnIrish.Name = "btnIrish";
            this.btnIrish.Size = new System.Drawing.Size(139, 160);
            this.btnIrish.TabIndex = 20;
            this.btnIrish.UseVisualStyleBackColor = true;
            this.btnIrish.Click += new System.EventHandler(this.btnIrish_Click);
            // 
            // btnPumpkin
            // 
            this.btnPumpkin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPumpkin.BackgroundImage")));
            this.btnPumpkin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPumpkin.Location = new System.Drawing.Point(351, 547);
            this.btnPumpkin.Name = "btnPumpkin";
            this.btnPumpkin.Size = new System.Drawing.Size(139, 160);
            this.btnPumpkin.TabIndex = 19;
            this.btnPumpkin.UseVisualStyleBackColor = true;
            this.btnPumpkin.Click += new System.EventHandler(this.btnPumpkin_Click);
            // 
            // btnAlmondMilk
            // 
            this.btnAlmondMilk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAlmondMilk.BackgroundImage")));
            this.btnAlmondMilk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAlmondMilk.Location = new System.Drawing.Point(187, 547);
            this.btnAlmondMilk.Name = "btnAlmondMilk";
            this.btnAlmondMilk.Size = new System.Drawing.Size(139, 160);
            this.btnAlmondMilk.TabIndex = 18;
            this.btnAlmondMilk.UseVisualStyleBackColor = true;
            this.btnAlmondMilk.Click += new System.EventHandler(this.btnAlmondMilk_Click);
            // 
            // btnMatchaLatte
            // 
            this.btnMatchaLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMatchaLatte.BackgroundImage")));
            this.btnMatchaLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMatchaLatte.Location = new System.Drawing.Point(509, 366);
            this.btnMatchaLatte.Name = "btnMatchaLatte";
            this.btnMatchaLatte.Size = new System.Drawing.Size(139, 160);
            this.btnMatchaLatte.TabIndex = 17;
            this.btnMatchaLatte.UseVisualStyleBackColor = true;
            this.btnMatchaLatte.Click += new System.EventHandler(this.btnMatchaLatte_Click);
            // 
            // btnChocoMint
            // 
            this.btnChocoMint.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChocoMint.BackgroundImage")));
            this.btnChocoMint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnChocoMint.Location = new System.Drawing.Point(351, 366);
            this.btnChocoMint.Name = "btnChocoMint";
            this.btnChocoMint.Size = new System.Drawing.Size(139, 160);
            this.btnChocoMint.TabIndex = 16;
            this.btnChocoMint.UseVisualStyleBackColor = true;
            this.btnChocoMint.Click += new System.EventHandler(this.btnChocoMint_Click);
            // 
            // btnPeanut
            // 
            this.btnPeanut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPeanut.BackgroundImage")));
            this.btnPeanut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPeanut.Location = new System.Drawing.Point(187, 366);
            this.btnPeanut.Name = "btnPeanut";
            this.btnPeanut.Size = new System.Drawing.Size(139, 160);
            this.btnPeanut.TabIndex = 15;
            this.btnPeanut.UseVisualStyleBackColor = true;
            this.btnPeanut.Click += new System.EventHandler(this.btnPeanut_Click);
            // 
            // btnMaple
            // 
            this.btnMaple.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMaple.BackgroundImage")));
            this.btnMaple.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMaple.Location = new System.Drawing.Point(509, 193);
            this.btnMaple.Name = "btnMaple";
            this.btnMaple.Size = new System.Drawing.Size(139, 157);
            this.btnMaple.TabIndex = 14;
            this.btnMaple.UseVisualStyleBackColor = true;
            this.btnMaple.Click += new System.EventHandler(this.btnMaple_Click);
            // 
            // btnCoconut
            // 
            this.btnCoconut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCoconut.BackgroundImage")));
            this.btnCoconut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCoconut.Location = new System.Drawing.Point(351, 193);
            this.btnCoconut.Name = "btnCoconut";
            this.btnCoconut.Size = new System.Drawing.Size(139, 157);
            this.btnCoconut.TabIndex = 13;
            this.btnCoconut.UseVisualStyleBackColor = true;
            this.btnCoconut.Click += new System.EventHandler(this.btnCoconut_Click);
            // 
            // btnHazelnut
            // 
            this.btnHazelnut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHazelnut.BackgroundImage")));
            this.btnHazelnut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnHazelnut.Location = new System.Drawing.Point(187, 191);
            this.btnHazelnut.Name = "btnHazelnut";
            this.btnHazelnut.Size = new System.Drawing.Size(139, 159);
            this.btnHazelnut.TabIndex = 12;
            this.btnHazelnut.UseVisualStyleBackColor = true;
            this.btnHazelnut.Click += new System.EventHandler(this.btnHazelnut_Click);
            // 
            // btnVanilla
            // 
            this.btnVanilla.BackColor = System.Drawing.Color.ForestGreen;
            this.btnVanilla.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnVanilla.BackgroundImage")));
            this.btnVanilla.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnVanilla.Location = new System.Drawing.Point(509, 18);
            this.btnVanilla.Name = "btnVanilla";
            this.btnVanilla.Size = new System.Drawing.Size(139, 160);
            this.btnVanilla.TabIndex = 11;
            this.btnVanilla.UseVisualStyleBackColor = false;
            this.btnVanilla.Click += new System.EventHandler(this.btnVanilla_Click);
            // 
            // btnMoca
            // 
            this.btnMoca.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMoca.BackgroundImage")));
            this.btnMoca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMoca.Location = new System.Drawing.Point(351, 17);
            this.btnMoca.Name = "btnMoca";
            this.btnMoca.Size = new System.Drawing.Size(139, 160);
            this.btnMoca.TabIndex = 10;
            this.btnMoca.UseVisualStyleBackColor = true;
            this.btnMoca.Click += new System.EventHandler(this.btnMoca_Click);
            // 
            // btnMacch
            // 
            this.btnMacch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMacch.BackgroundImage")));
            this.btnMacch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMacch.Location = new System.Drawing.Point(187, 17);
            this.btnMacch.Name = "btnMacch";
            this.btnMacch.Size = new System.Drawing.Size(139, 160);
            this.btnMacch.TabIndex = 9;
            this.btnMacch.UseVisualStyleBackColor = true;
            this.btnMacch.Click += new System.EventHandler(this.btnMacch_Click);
            // 
            // btnChaiLatte
            // 
            this.btnChaiLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChaiLatte.BackgroundImage")));
            this.btnChaiLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnChaiLatte.Location = new System.Drawing.Point(28, 547);
            this.btnChaiLatte.Name = "btnChaiLatte";
            this.btnChaiLatte.Size = new System.Drawing.Size(139, 160);
            this.btnChaiLatte.TabIndex = 8;
            this.btnChaiLatte.UseVisualStyleBackColor = true;
            this.btnChaiLatte.Click += new System.EventHandler(this.btnChaiLatte_Click);
            // 
            // btnLavender
            // 
            this.btnLavender.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLavender.BackgroundImage")));
            this.btnLavender.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLavender.Location = new System.Drawing.Point(28, 366);
            this.btnLavender.Name = "btnLavender";
            this.btnLavender.Size = new System.Drawing.Size(139, 160);
            this.btnLavender.TabIndex = 7;
            this.btnLavender.UseVisualStyleBackColor = true;
            this.btnLavender.Click += new System.EventHandler(this.btnLavender_Click);
            // 
            // btnCaramel
            // 
            this.btnCaramel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCaramel.BackgroundImage")));
            this.btnCaramel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCaramel.Location = new System.Drawing.Point(28, 190);
            this.btnCaramel.Name = "btnCaramel";
            this.btnCaramel.Size = new System.Drawing.Size(139, 160);
            this.btnCaramel.TabIndex = 6;
            this.btnCaramel.UseVisualStyleBackColor = true;
            this.btnCaramel.Click += new System.EventHandler(this.btnCaramel_Click);
            // 
            // btnKapeBrusko
            // 
            this.btnKapeBrusko.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKapeBrusko.BackgroundImage")));
            this.btnKapeBrusko.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnKapeBrusko.Location = new System.Drawing.Point(28, 17);
            this.btnKapeBrusko.Name = "btnKapeBrusko";
            this.btnKapeBrusko.Size = new System.Drawing.Size(139, 160);
            this.btnKapeBrusko.TabIndex = 5;
            this.btnKapeBrusko.UseVisualStyleBackColor = true;
            this.btnKapeBrusko.Click += new System.EventHandler(this.btnKapeBrusko_Click);
            // 
            // btnMilkTea
            // 
            this.btnMilkTea.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnMilkTea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnMilkTea.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMilkTea.Location = new System.Drawing.Point(155, 167);
            this.btnMilkTea.Name = "btnMilkTea";
            this.btnMilkTea.Size = new System.Drawing.Size(133, 45);
            this.btnMilkTea.TabIndex = 1;
            this.btnMilkTea.Text = "Milk Tea";
            this.btnMilkTea.UseVisualStyleBackColor = false;
            this.btnMilkTea.Click += new System.EventHandler(this.btnMilkTea_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(83, 40);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(104, 28);
            this.button18.TabIndex = 2;
            this.button18.Text = "Logout";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button19.BackColor = System.Drawing.SystemColors.Control;
            this.button19.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(1312, -1);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(25, 24);
            this.button19.TabIndex = 3;
            this.button19.Text = "X";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // btnMaximize
            // 
            this.btnMaximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximize.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMaximize.BackgroundImage")));
            this.btnMaximize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMaximize.Location = new System.Drawing.Point(1289, -1);
            this.btnMaximize.Name = "btnMaximize";
            this.btnMaximize.Size = new System.Drawing.Size(25, 24);
            this.btnMaximize.TabIndex = 4;
            this.btnMaximize.UseVisualStyleBackColor = true;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.BackColor = System.Drawing.SystemColors.Control;
            this.btnMinimize.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMinimize.BackgroundImage")));
            this.btnMinimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMinimize.Location = new System.Drawing.Point(1267, -1);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(25, 25);
            this.btnMinimize.TabIndex = 5;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnIcedCoffee
            // 
            this.btnIcedCoffee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnIcedCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIcedCoffee.Location = new System.Drawing.Point(294, 167);
            this.btnIcedCoffee.Name = "btnIcedCoffee";
            this.btnIcedCoffee.Size = new System.Drawing.Size(128, 45);
            this.btnIcedCoffee.TabIndex = 6;
            this.btnIcedCoffee.Text = "Iced Coffee";
            this.btnIcedCoffee.UseVisualStyleBackColor = false;
            this.btnIcedCoffee.Click += new System.EventHandler(this.btnIcedCoffee_Click);
            // 
            // btnFruitTea
            // 
            this.btnFruitTea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnFruitTea.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFruitTea.Location = new System.Drawing.Point(433, 167);
            this.btnFruitTea.Name = "btnFruitTea";
            this.btnFruitTea.Size = new System.Drawing.Size(128, 45);
            this.btnFruitTea.TabIndex = 19;
            this.btnFruitTea.Text = "Fruit Tea";
            this.btnFruitTea.UseVisualStyleBackColor = false;
            this.btnFruitTea.Click += new System.EventHandler(this.btnFruitTea_Click);
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.btnCoconutTea);
            this.panel3.Controls.Add(this.btnHoneyDew);
            this.panel3.Controls.Add(this.btnPomegranate);
            this.panel3.Controls.Add(this.btnDragonFruit);
            this.panel3.Controls.Add(this.btnLycheeTea);
            this.panel3.Controls.Add(this.btnApple);
            this.panel3.Controls.Add(this.btnCherry);
            this.panel3.Controls.Add(this.btnPineappleTea);
            this.panel3.Controls.Add(this.btnBlueberry);
            this.panel3.Controls.Add(this.btnLemonTea);
            this.panel3.Controls.Add(this.btnStrawberryTea);
            this.panel3.Controls.Add(this.btnMango);
            this.panel3.Controls.Add(this.btnCranberry);
            this.panel3.Controls.Add(this.btnGrapefruit);
            this.panel3.Controls.Add(this.btnWatermelonTea);
            this.panel3.Controls.Add(this.btnPeach);
            this.panel3.Location = new System.Drawing.Point(150, 218);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(698, 541);
            this.panel3.TabIndex = 20;
            // 
            // btnCoconutTea
            // 
            this.btnCoconutTea.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCoconutTea.BackgroundImage")));
            this.btnCoconutTea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCoconutTea.Location = new System.Drawing.Point(529, 538);
            this.btnCoconutTea.Name = "btnCoconutTea";
            this.btnCoconutTea.Size = new System.Drawing.Size(139, 160);
            this.btnCoconutTea.TabIndex = 20;
            this.btnCoconutTea.UseVisualStyleBackColor = true;
            this.btnCoconutTea.Click += new System.EventHandler(this.btnCoconutTea_Click);
            // 
            // btnHoneyDew
            // 
            this.btnHoneyDew.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHoneyDew.BackgroundImage")));
            this.btnHoneyDew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHoneyDew.Location = new System.Drawing.Point(364, 538);
            this.btnHoneyDew.Name = "btnHoneyDew";
            this.btnHoneyDew.Size = new System.Drawing.Size(139, 160);
            this.btnHoneyDew.TabIndex = 19;
            this.btnHoneyDew.UseVisualStyleBackColor = true;
            this.btnHoneyDew.Click += new System.EventHandler(this.btnHoneyDew_Click);
            // 
            // btnPomegranate
            // 
            this.btnPomegranate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPomegranate.BackgroundImage")));
            this.btnPomegranate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPomegranate.Location = new System.Drawing.Point(195, 538);
            this.btnPomegranate.Name = "btnPomegranate";
            this.btnPomegranate.Size = new System.Drawing.Size(139, 160);
            this.btnPomegranate.TabIndex = 18;
            this.btnPomegranate.UseVisualStyleBackColor = true;
            this.btnPomegranate.Click += new System.EventHandler(this.btnPomegranate_Click);
            // 
            // btnDragonFruit
            // 
            this.btnDragonFruit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDragonFruit.BackgroundImage")));
            this.btnDragonFruit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDragonFruit.Location = new System.Drawing.Point(529, 366);
            this.btnDragonFruit.Name = "btnDragonFruit";
            this.btnDragonFruit.Size = new System.Drawing.Size(139, 160);
            this.btnDragonFruit.TabIndex = 17;
            this.btnDragonFruit.UseVisualStyleBackColor = true;
            this.btnDragonFruit.Click += new System.EventHandler(this.btnDragonFruit_Click);
            // 
            // btnLycheeTea
            // 
            this.btnLycheeTea.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLycheeTea.BackgroundImage")));
            this.btnLycheeTea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLycheeTea.Location = new System.Drawing.Point(364, 366);
            this.btnLycheeTea.Name = "btnLycheeTea";
            this.btnLycheeTea.Size = new System.Drawing.Size(139, 160);
            this.btnLycheeTea.TabIndex = 16;
            this.btnLycheeTea.UseVisualStyleBackColor = true;
            this.btnLycheeTea.Click += new System.EventHandler(this.btnLycheeTea_Click);
            // 
            // btnApple
            // 
            this.btnApple.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnApple.BackgroundImage")));
            this.btnApple.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnApple.Location = new System.Drawing.Point(195, 366);
            this.btnApple.Name = "btnApple";
            this.btnApple.Size = new System.Drawing.Size(139, 160);
            this.btnApple.TabIndex = 15;
            this.btnApple.UseVisualStyleBackColor = true;
            this.btnApple.Click += new System.EventHandler(this.btnApple_Click);
            // 
            // btnCherry
            // 
            this.btnCherry.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCherry.BackgroundImage")));
            this.btnCherry.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCherry.Location = new System.Drawing.Point(529, 193);
            this.btnCherry.Name = "btnCherry";
            this.btnCherry.Size = new System.Drawing.Size(139, 160);
            this.btnCherry.TabIndex = 14;
            this.btnCherry.UseVisualStyleBackColor = true;
            this.btnCherry.Click += new System.EventHandler(this.btnCherry_Click);
            // 
            // btnPineappleTea
            // 
            this.btnPineappleTea.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPineappleTea.BackgroundImage")));
            this.btnPineappleTea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPineappleTea.Location = new System.Drawing.Point(364, 193);
            this.btnPineappleTea.Name = "btnPineappleTea";
            this.btnPineappleTea.Size = new System.Drawing.Size(139, 160);
            this.btnPineappleTea.TabIndex = 13;
            this.btnPineappleTea.UseVisualStyleBackColor = true;
            this.btnPineappleTea.Click += new System.EventHandler(this.btnPineappleTea_Click);
            // 
            // btnBlueberry
            // 
            this.btnBlueberry.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBlueberry.BackgroundImage")));
            this.btnBlueberry.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBlueberry.Location = new System.Drawing.Point(195, 193);
            this.btnBlueberry.Name = "btnBlueberry";
            this.btnBlueberry.Size = new System.Drawing.Size(139, 160);
            this.btnBlueberry.TabIndex = 12;
            this.btnBlueberry.UseVisualStyleBackColor = true;
            this.btnBlueberry.Click += new System.EventHandler(this.btnBlueberry_Click);
            // 
            // btnLemonTea
            // 
            this.btnLemonTea.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLemonTea.BackgroundImage")));
            this.btnLemonTea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLemonTea.Location = new System.Drawing.Point(529, 20);
            this.btnLemonTea.Name = "btnLemonTea";
            this.btnLemonTea.Size = new System.Drawing.Size(139, 160);
            this.btnLemonTea.TabIndex = 11;
            this.btnLemonTea.UseVisualStyleBackColor = true;
            this.btnLemonTea.Click += new System.EventHandler(this.btnLemonTea_Click);
            // 
            // btnStrawberryTea
            // 
            this.btnStrawberryTea.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStrawberryTea.BackgroundImage")));
            this.btnStrawberryTea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStrawberryTea.Location = new System.Drawing.Point(364, 20);
            this.btnStrawberryTea.Name = "btnStrawberryTea";
            this.btnStrawberryTea.Size = new System.Drawing.Size(139, 160);
            this.btnStrawberryTea.TabIndex = 10;
            this.btnStrawberryTea.UseVisualStyleBackColor = true;
            this.btnStrawberryTea.Click += new System.EventHandler(this.btnStrawberryTea_Click);
            // 
            // btnMango
            // 
            this.btnMango.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMango.BackgroundImage")));
            this.btnMango.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMango.Location = new System.Drawing.Point(195, 20);
            this.btnMango.Name = "btnMango";
            this.btnMango.Size = new System.Drawing.Size(139, 160);
            this.btnMango.TabIndex = 9;
            this.btnMango.UseVisualStyleBackColor = true;
            this.btnMango.Click += new System.EventHandler(this.btnMango_Click);
            // 
            // btnCranberry
            // 
            this.btnCranberry.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCranberry.BackgroundImage")));
            this.btnCranberry.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCranberry.Location = new System.Drawing.Point(28, 537);
            this.btnCranberry.Name = "btnCranberry";
            this.btnCranberry.Size = new System.Drawing.Size(139, 160);
            this.btnCranberry.TabIndex = 8;
            this.btnCranberry.UseVisualStyleBackColor = true;
            this.btnCranberry.Click += new System.EventHandler(this.btnCranberry_Click);
            // 
            // btnGrapefruit
            // 
            this.btnGrapefruit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGrapefruit.BackgroundImage")));
            this.btnGrapefruit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGrapefruit.Location = new System.Drawing.Point(28, 366);
            this.btnGrapefruit.Name = "btnGrapefruit";
            this.btnGrapefruit.Size = new System.Drawing.Size(139, 160);
            this.btnGrapefruit.TabIndex = 7;
            this.btnGrapefruit.UseVisualStyleBackColor = true;
            this.btnGrapefruit.Click += new System.EventHandler(this.btnGrapefruit_Click);
            // 
            // btnWatermelonTea
            // 
            this.btnWatermelonTea.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWatermelonTea.BackgroundImage")));
            this.btnWatermelonTea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnWatermelonTea.Location = new System.Drawing.Point(28, 193);
            this.btnWatermelonTea.Name = "btnWatermelonTea";
            this.btnWatermelonTea.Size = new System.Drawing.Size(139, 160);
            this.btnWatermelonTea.TabIndex = 6;
            this.btnWatermelonTea.UseVisualStyleBackColor = true;
            this.btnWatermelonTea.Click += new System.EventHandler(this.btnWatermelonTea_Click);
            // 
            // btnPeach
            // 
            this.btnPeach.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPeach.BackgroundImage")));
            this.btnPeach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPeach.Location = new System.Drawing.Point(28, 17);
            this.btnPeach.Name = "btnPeach";
            this.btnPeach.Size = new System.Drawing.Size(139, 160);
            this.btnPeach.TabIndex = 5;
            this.btnPeach.UseVisualStyleBackColor = true;
            this.btnPeach.Click += new System.EventHandler(this.btnPeach_Click);
            // 
            // btnPraf
            // 
            this.btnPraf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnPraf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPraf.Location = new System.Drawing.Point(571, 167);
            this.btnPraf.Name = "btnPraf";
            this.btnPraf.Size = new System.Drawing.Size(128, 45);
            this.btnPraf.TabIndex = 21;
            this.btnPraf.Text = "Frappe";
            this.btnPraf.UseVisualStyleBackColor = false;
            this.btnPraf.Click += new System.EventHandler(this.btnPraf_Click);
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.Controls.Add(this.btnMachaGreenTea);
            this.panel4.Controls.Add(this.btnChaiLatteFrappe);
            this.panel4.Controls.Add(this.btnRedVelvetFrappe);
            this.panel4.Controls.Add(this.btnBananaMochaFrappe);
            this.panel4.Controls.Add(this.btnStrawberryFrappe);
            this.panel4.Controls.Add(this.btnPumpkinSpice);
            this.panel4.Controls.Add(this.btnToffeeNut);
            this.panel4.Controls.Add(this.btnPeanutButterFrappe);
            this.panel4.Controls.Add(this.btnCookiesAndCream);
            this.panel4.Controls.Add(this.btnChocoloateFrappe);
            this.panel4.Controls.Add(this.btnCoconutFrappe);
            this.panel4.Controls.Add(this.btnHazelnutFrappe);
            this.panel4.Controls.Add(this.btnVanillaFrappe);
            this.panel4.Controls.Add(this.btnCaramelFrappe);
            this.panel4.Controls.Add(this.btnMochaFrappe);
            this.panel4.Controls.Add(this.btnClassicCofee);
            this.panel4.Location = new System.Drawing.Point(146, 218);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(702, 541);
            this.panel4.TabIndex = 22;
            // 
            // btnMachaGreenTea
            // 
            this.btnMachaGreenTea.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMachaGreenTea.BackgroundImage")));
            this.btnMachaGreenTea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMachaGreenTea.Location = new System.Drawing.Point(533, 378);
            this.btnMachaGreenTea.Name = "btnMachaGreenTea";
            this.btnMachaGreenTea.Size = new System.Drawing.Size(139, 160);
            this.btnMachaGreenTea.TabIndex = 25;
            this.btnMachaGreenTea.UseVisualStyleBackColor = true;
            this.btnMachaGreenTea.Click += new System.EventHandler(this.btnMachaGreenTea_Click);
            // 
            // btnChaiLatteFrappe
            // 
            this.btnChaiLatteFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChaiLatteFrappe.BackgroundImage")));
            this.btnChaiLatteFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnChaiLatteFrappe.Location = new System.Drawing.Point(368, 378);
            this.btnChaiLatteFrappe.Name = "btnChaiLatteFrappe";
            this.btnChaiLatteFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnChaiLatteFrappe.TabIndex = 24;
            this.btnChaiLatteFrappe.UseVisualStyleBackColor = true;
            this.btnChaiLatteFrappe.Click += new System.EventHandler(this.btnChaiLatteFrappe_Click);
            // 
            // btnRedVelvetFrappe
            // 
            this.btnRedVelvetFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRedVelvetFrappe.BackgroundImage")));
            this.btnRedVelvetFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRedVelvetFrappe.Location = new System.Drawing.Point(533, 557);
            this.btnRedVelvetFrappe.Name = "btnRedVelvetFrappe";
            this.btnRedVelvetFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnRedVelvetFrappe.TabIndex = 23;
            this.btnRedVelvetFrappe.UseVisualStyleBackColor = true;
            this.btnRedVelvetFrappe.Click += new System.EventHandler(this.btnRedVelvetFrappe_Click);
            // 
            // btnBananaMochaFrappe
            // 
            this.btnBananaMochaFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBananaMochaFrappe.BackgroundImage")));
            this.btnBananaMochaFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBananaMochaFrappe.Location = new System.Drawing.Point(368, 557);
            this.btnBananaMochaFrappe.Name = "btnBananaMochaFrappe";
            this.btnBananaMochaFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnBananaMochaFrappe.TabIndex = 22;
            this.btnBananaMochaFrappe.UseVisualStyleBackColor = true;
            this.btnBananaMochaFrappe.Click += new System.EventHandler(this.btnBananaMochaFrappe_Click);
            // 
            // btnStrawberryFrappe
            // 
            this.btnStrawberryFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStrawberryFrappe.BackgroundImage")));
            this.btnStrawberryFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStrawberryFrappe.Location = new System.Drawing.Point(199, 557);
            this.btnStrawberryFrappe.Name = "btnStrawberryFrappe";
            this.btnStrawberryFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnStrawberryFrappe.TabIndex = 21;
            this.btnStrawberryFrappe.UseVisualStyleBackColor = true;
            this.btnStrawberryFrappe.Click += new System.EventHandler(this.btnStrawberryFrappe_Click);
            // 
            // btnPumpkinSpice
            // 
            this.btnPumpkinSpice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPumpkinSpice.BackgroundImage")));
            this.btnPumpkinSpice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPumpkinSpice.Location = new System.Drawing.Point(199, 378);
            this.btnPumpkinSpice.Name = "btnPumpkinSpice";
            this.btnPumpkinSpice.Size = new System.Drawing.Size(139, 160);
            this.btnPumpkinSpice.TabIndex = 20;
            this.btnPumpkinSpice.UseVisualStyleBackColor = true;
            this.btnPumpkinSpice.Click += new System.EventHandler(this.btnPumpkinSpice_Click);
            // 
            // btnToffeeNut
            // 
            this.btnToffeeNut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnToffeeNut.BackgroundImage")));
            this.btnToffeeNut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnToffeeNut.Location = new System.Drawing.Point(32, 556);
            this.btnToffeeNut.Name = "btnToffeeNut";
            this.btnToffeeNut.Size = new System.Drawing.Size(139, 160);
            this.btnToffeeNut.TabIndex = 19;
            this.btnToffeeNut.UseVisualStyleBackColor = true;
            this.btnToffeeNut.Click += new System.EventHandler(this.btnToffeeNut_Click);
            // 
            // btnPeanutButterFrappe
            // 
            this.btnPeanutButterFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPeanutButterFrappe.BackgroundImage")));
            this.btnPeanutButterFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPeanutButterFrappe.Location = new System.Drawing.Point(533, 200);
            this.btnPeanutButterFrappe.Name = "btnPeanutButterFrappe";
            this.btnPeanutButterFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnPeanutButterFrappe.TabIndex = 18;
            this.btnPeanutButterFrappe.UseVisualStyleBackColor = true;
            this.btnPeanutButterFrappe.Click += new System.EventHandler(this.btnPeanutButterFrappe_Click);
            // 
            // btnCookiesAndCream
            // 
            this.btnCookiesAndCream.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCookiesAndCream.BackgroundImage")));
            this.btnCookiesAndCream.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCookiesAndCream.Location = new System.Drawing.Point(368, 200);
            this.btnCookiesAndCream.Name = "btnCookiesAndCream";
            this.btnCookiesAndCream.Size = new System.Drawing.Size(139, 160);
            this.btnCookiesAndCream.TabIndex = 17;
            this.btnCookiesAndCream.UseVisualStyleBackColor = true;
            this.btnCookiesAndCream.Click += new System.EventHandler(this.btnCookiesAndCream_Click);
            // 
            // btnChocoloateFrappe
            // 
            this.btnChocoloateFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChocoloateFrappe.BackgroundImage")));
            this.btnChocoloateFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnChocoloateFrappe.Location = new System.Drawing.Point(199, 200);
            this.btnChocoloateFrappe.Name = "btnChocoloateFrappe";
            this.btnChocoloateFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnChocoloateFrappe.TabIndex = 16;
            this.btnChocoloateFrappe.UseVisualStyleBackColor = true;
            this.btnChocoloateFrappe.Click += new System.EventHandler(this.btnChocoloateFrappe_Click);
            // 
            // btnCoconutFrappe
            // 
            this.btnCoconutFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCoconutFrappe.BackgroundImage")));
            this.btnCoconutFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCoconutFrappe.Location = new System.Drawing.Point(32, 378);
            this.btnCoconutFrappe.Name = "btnCoconutFrappe";
            this.btnCoconutFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnCoconutFrappe.TabIndex = 15;
            this.btnCoconutFrappe.UseVisualStyleBackColor = true;
            this.btnCoconutFrappe.Click += new System.EventHandler(this.btnCoconutFrappe_Click);
            // 
            // btnHazelnutFrappe
            // 
            this.btnHazelnutFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHazelnutFrappe.BackgroundImage")));
            this.btnHazelnutFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHazelnutFrappe.Location = new System.Drawing.Point(32, 200);
            this.btnHazelnutFrappe.Name = "btnHazelnutFrappe";
            this.btnHazelnutFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnHazelnutFrappe.TabIndex = 14;
            this.btnHazelnutFrappe.UseVisualStyleBackColor = true;
            this.btnHazelnutFrappe.Click += new System.EventHandler(this.btnHazelnutFrappe_Click);
            // 
            // btnVanillaFrappe
            // 
            this.btnVanillaFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnVanillaFrappe.BackgroundImage")));
            this.btnVanillaFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnVanillaFrappe.Location = new System.Drawing.Point(533, 17);
            this.btnVanillaFrappe.Name = "btnVanillaFrappe";
            this.btnVanillaFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnVanillaFrappe.TabIndex = 13;
            this.btnVanillaFrappe.UseVisualStyleBackColor = true;
            this.btnVanillaFrappe.Click += new System.EventHandler(this.btnVanillaFrappe_Click);
            // 
            // btnCaramelFrappe
            // 
            this.btnCaramelFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCaramelFrappe.BackgroundImage")));
            this.btnCaramelFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCaramelFrappe.Location = new System.Drawing.Point(368, 17);
            this.btnCaramelFrappe.Name = "btnCaramelFrappe";
            this.btnCaramelFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnCaramelFrappe.TabIndex = 12;
            this.btnCaramelFrappe.UseVisualStyleBackColor = true;
            this.btnCaramelFrappe.Click += new System.EventHandler(this.btnCaramelFrappe_Click);
            // 
            // btnMochaFrappe
            // 
            this.btnMochaFrappe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMochaFrappe.BackgroundImage")));
            this.btnMochaFrappe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMochaFrappe.Location = new System.Drawing.Point(199, 17);
            this.btnMochaFrappe.Name = "btnMochaFrappe";
            this.btnMochaFrappe.Size = new System.Drawing.Size(139, 160);
            this.btnMochaFrappe.TabIndex = 11;
            this.btnMochaFrappe.UseVisualStyleBackColor = true;
            this.btnMochaFrappe.Click += new System.EventHandler(this.btnMochaFrappe_Click);
            // 
            // btnClassicCofee
            // 
            this.btnClassicCofee.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClassicCofee.BackgroundImage")));
            this.btnClassicCofee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClassicCofee.Location = new System.Drawing.Point(32, 17);
            this.btnClassicCofee.Name = "btnClassicCofee";
            this.btnClassicCofee.Size = new System.Drawing.Size(139, 160);
            this.btnClassicCofee.TabIndex = 10;
            this.btnClassicCofee.UseVisualStyleBackColor = true;
            this.btnClassicCofee.Click += new System.EventHandler(this.btnClassicCofee_Click);
            // 
            // btnHotBrew
            // 
            this.btnHotBrew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnHotBrew.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHotBrew.Location = new System.Drawing.Point(709, 167);
            this.btnHotBrew.Name = "btnHotBrew";
            this.btnHotBrew.Size = new System.Drawing.Size(128, 45);
            this.btnHotBrew.TabIndex = 23;
            this.btnHotBrew.Text = "Hot Brew";
            this.btnHotBrew.UseVisualStyleBackColor = false;
            this.btnHotBrew.Click += new System.EventHandler(this.btnHotBrew_Click);
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.btnClassicMocha);
            this.panel5.Controls.Add(this.btnChaiLatteHot);
            this.panel5.Controls.Add(this.btnIrishCreamLatte);
            this.panel5.Controls.Add(this.btnCoconutMochaLatte);
            this.panel5.Controls.Add(this.btnAlmondJoy);
            this.panel5.Controls.Add(this.btnMexicanMocha);
            this.panel5.Controls.Add(this.btnGingerbreadLatte);
            this.panel5.Controls.Add(this.btnSaltedCaramelLatte);
            this.panel5.Controls.Add(this.btnHoneyAlmondLatte);
            this.panel5.Controls.Add(this.btnToastedMarshmallow);
            this.panel5.Controls.Add(this.btnCinnamonDolceLatte);
            this.panel5.Controls.Add(this.btnHazelnutHotBrew);
            this.panel5.Controls.Add(this.btnLavenderLatteHot);
            this.panel5.Controls.Add(this.btnBrownSugarOathMilk);
            this.panel5.Controls.Add(this.btnMaplePecanLatte);
            this.panel5.Controls.Add(this.btnCaramelMacchiato);
            this.panel5.Location = new System.Drawing.Point(146, 218);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(702, 542);
            this.panel5.TabIndex = 24;
            // 
            // btnClassicMocha
            // 
            this.btnClassicMocha.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClassicMocha.BackgroundImage")));
            this.btnClassicMocha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClassicMocha.Location = new System.Drawing.Point(533, 548);
            this.btnClassicMocha.Name = "btnClassicMocha";
            this.btnClassicMocha.Size = new System.Drawing.Size(139, 160);
            this.btnClassicMocha.TabIndex = 27;
            this.btnClassicMocha.UseVisualStyleBackColor = true;
            this.btnClassicMocha.Click += new System.EventHandler(this.btnClassicMocha_Click);
            // 
            // btnChaiLatteHot
            // 
            this.btnChaiLatteHot.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChaiLatteHot.BackgroundImage")));
            this.btnChaiLatteHot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnChaiLatteHot.Location = new System.Drawing.Point(368, 549);
            this.btnChaiLatteHot.Name = "btnChaiLatteHot";
            this.btnChaiLatteHot.Size = new System.Drawing.Size(139, 160);
            this.btnChaiLatteHot.TabIndex = 26;
            this.btnChaiLatteHot.UseVisualStyleBackColor = true;
            this.btnChaiLatteHot.Click += new System.EventHandler(this.btnChaiLatteHot_Click);
            // 
            // btnIrishCreamLatte
            // 
            this.btnIrishCreamLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnIrishCreamLatte.BackgroundImage")));
            this.btnIrishCreamLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIrishCreamLatte.Location = new System.Drawing.Point(199, 549);
            this.btnIrishCreamLatte.Name = "btnIrishCreamLatte";
            this.btnIrishCreamLatte.Size = new System.Drawing.Size(139, 160);
            this.btnIrishCreamLatte.TabIndex = 25;
            this.btnIrishCreamLatte.UseVisualStyleBackColor = true;
            this.btnIrishCreamLatte.Click += new System.EventHandler(this.btnIrishCreamLatte_Click);
            // 
            // btnCoconutMochaLatte
            // 
            this.btnCoconutMochaLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCoconutMochaLatte.BackgroundImage")));
            this.btnCoconutMochaLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCoconutMochaLatte.Location = new System.Drawing.Point(533, 366);
            this.btnCoconutMochaLatte.Name = "btnCoconutMochaLatte";
            this.btnCoconutMochaLatte.Size = new System.Drawing.Size(139, 160);
            this.btnCoconutMochaLatte.TabIndex = 24;
            this.btnCoconutMochaLatte.UseVisualStyleBackColor = true;
            this.btnCoconutMochaLatte.Click += new System.EventHandler(this.btnCoconutMochaLatte_Click);
            // 
            // btnAlmondJoy
            // 
            this.btnAlmondJoy.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAlmondJoy.BackgroundImage")));
            this.btnAlmondJoy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAlmondJoy.Location = new System.Drawing.Point(368, 366);
            this.btnAlmondJoy.Name = "btnAlmondJoy";
            this.btnAlmondJoy.Size = new System.Drawing.Size(139, 160);
            this.btnAlmondJoy.TabIndex = 23;
            this.btnAlmondJoy.UseVisualStyleBackColor = true;
            this.btnAlmondJoy.Click += new System.EventHandler(this.btnAlmondJoy_Click);
            // 
            // btnMexicanMocha
            // 
            this.btnMexicanMocha.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMexicanMocha.BackgroundImage")));
            this.btnMexicanMocha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMexicanMocha.Location = new System.Drawing.Point(199, 366);
            this.btnMexicanMocha.Name = "btnMexicanMocha";
            this.btnMexicanMocha.Size = new System.Drawing.Size(139, 160);
            this.btnMexicanMocha.TabIndex = 22;
            this.btnMexicanMocha.UseVisualStyleBackColor = true;
            this.btnMexicanMocha.Click += new System.EventHandler(this.btnMexicanMocha_Click);
            // 
            // btnGingerbreadLatte
            // 
            this.btnGingerbreadLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGingerbreadLatte.BackgroundImage")));
            this.btnGingerbreadLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGingerbreadLatte.Location = new System.Drawing.Point(533, 193);
            this.btnGingerbreadLatte.Name = "btnGingerbreadLatte";
            this.btnGingerbreadLatte.Size = new System.Drawing.Size(139, 160);
            this.btnGingerbreadLatte.TabIndex = 21;
            this.btnGingerbreadLatte.UseVisualStyleBackColor = true;
            this.btnGingerbreadLatte.Click += new System.EventHandler(this.btnGingerbreadLatte_Click);
            // 
            // btnSaltedCaramelLatte
            // 
            this.btnSaltedCaramelLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSaltedCaramelLatte.BackgroundImage")));
            this.btnSaltedCaramelLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSaltedCaramelLatte.Location = new System.Drawing.Point(368, 192);
            this.btnSaltedCaramelLatte.Name = "btnSaltedCaramelLatte";
            this.btnSaltedCaramelLatte.Size = new System.Drawing.Size(139, 160);
            this.btnSaltedCaramelLatte.TabIndex = 20;
            this.btnSaltedCaramelLatte.UseVisualStyleBackColor = true;
            this.btnSaltedCaramelLatte.Click += new System.EventHandler(this.btnSaltedCaramelLatte_Click);
            // 
            // btnHoneyAlmondLatte
            // 
            this.btnHoneyAlmondLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHoneyAlmondLatte.BackgroundImage")));
            this.btnHoneyAlmondLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHoneyAlmondLatte.Location = new System.Drawing.Point(199, 193);
            this.btnHoneyAlmondLatte.Name = "btnHoneyAlmondLatte";
            this.btnHoneyAlmondLatte.Size = new System.Drawing.Size(139, 160);
            this.btnHoneyAlmondLatte.TabIndex = 19;
            this.btnHoneyAlmondLatte.UseVisualStyleBackColor = true;
            this.btnHoneyAlmondLatte.Click += new System.EventHandler(this.btnHoneyAlmondLatte_Click);
            // 
            // btnToastedMarshmallow
            // 
            this.btnToastedMarshmallow.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnToastedMarshmallow.BackgroundImage")));
            this.btnToastedMarshmallow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnToastedMarshmallow.Location = new System.Drawing.Point(533, 17);
            this.btnToastedMarshmallow.Name = "btnToastedMarshmallow";
            this.btnToastedMarshmallow.Size = new System.Drawing.Size(139, 160);
            this.btnToastedMarshmallow.TabIndex = 18;
            this.btnToastedMarshmallow.UseVisualStyleBackColor = true;
            this.btnToastedMarshmallow.Click += new System.EventHandler(this.btnToastedMarshmallow_Click);
            // 
            // btnCinnamonDolceLatte
            // 
            this.btnCinnamonDolceLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCinnamonDolceLatte.BackgroundImage")));
            this.btnCinnamonDolceLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCinnamonDolceLatte.Location = new System.Drawing.Point(368, 17);
            this.btnCinnamonDolceLatte.Name = "btnCinnamonDolceLatte";
            this.btnCinnamonDolceLatte.Size = new System.Drawing.Size(139, 160);
            this.btnCinnamonDolceLatte.TabIndex = 17;
            this.btnCinnamonDolceLatte.UseVisualStyleBackColor = true;
            this.btnCinnamonDolceLatte.Click += new System.EventHandler(this.btnCinnamonDolceLatte_Click);
            // 
            // btnHazelnutHotBrew
            // 
            this.btnHazelnutHotBrew.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHazelnutHotBrew.BackgroundImage")));
            this.btnHazelnutHotBrew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHazelnutHotBrew.Location = new System.Drawing.Point(199, 17);
            this.btnHazelnutHotBrew.Name = "btnHazelnutHotBrew";
            this.btnHazelnutHotBrew.Size = new System.Drawing.Size(139, 160);
            this.btnHazelnutHotBrew.TabIndex = 16;
            this.btnHazelnutHotBrew.UseVisualStyleBackColor = true;
            this.btnHazelnutHotBrew.Click += new System.EventHandler(this.btnHazelnutHotBrew_Click);
            // 
            // btnLavenderLatteHot
            // 
            this.btnLavenderLatteHot.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLavenderLatteHot.BackgroundImage")));
            this.btnLavenderLatteHot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLavenderLatteHot.Location = new System.Drawing.Point(32, 549);
            this.btnLavenderLatteHot.Name = "btnLavenderLatteHot";
            this.btnLavenderLatteHot.Size = new System.Drawing.Size(139, 160);
            this.btnLavenderLatteHot.TabIndex = 15;
            this.btnLavenderLatteHot.UseVisualStyleBackColor = true;
            this.btnLavenderLatteHot.Click += new System.EventHandler(this.btnLavenderLatteHot_Click);
            // 
            // btnBrownSugarOathMilk
            // 
            this.btnBrownSugarOathMilk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrownSugarOathMilk.BackgroundImage")));
            this.btnBrownSugarOathMilk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBrownSugarOathMilk.Location = new System.Drawing.Point(32, 366);
            this.btnBrownSugarOathMilk.Name = "btnBrownSugarOathMilk";
            this.btnBrownSugarOathMilk.Size = new System.Drawing.Size(139, 160);
            this.btnBrownSugarOathMilk.TabIndex = 14;
            this.btnBrownSugarOathMilk.UseVisualStyleBackColor = true;
            this.btnBrownSugarOathMilk.Click += new System.EventHandler(this.btnBrownSugarOathMilk_Click);
            // 
            // btnMaplePecanLatte
            // 
            this.btnMaplePecanLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMaplePecanLatte.BackgroundImage")));
            this.btnMaplePecanLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMaplePecanLatte.Location = new System.Drawing.Point(32, 193);
            this.btnMaplePecanLatte.Name = "btnMaplePecanLatte";
            this.btnMaplePecanLatte.Size = new System.Drawing.Size(139, 160);
            this.btnMaplePecanLatte.TabIndex = 13;
            this.btnMaplePecanLatte.UseVisualStyleBackColor = true;
            this.btnMaplePecanLatte.Click += new System.EventHandler(this.btnMaplePecanLatte_Click);
            // 
            // btnCaramelMacchiato
            // 
            this.btnCaramelMacchiato.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCaramelMacchiato.BackgroundImage")));
            this.btnCaramelMacchiato.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCaramelMacchiato.Location = new System.Drawing.Point(32, 17);
            this.btnCaramelMacchiato.Name = "btnCaramelMacchiato";
            this.btnCaramelMacchiato.Size = new System.Drawing.Size(139, 160);
            this.btnCaramelMacchiato.TabIndex = 12;
            this.btnCaramelMacchiato.UseVisualStyleBackColor = true;
            this.btnCaramelMacchiato.Click += new System.EventHandler(this.btnCaramelMacchiato_Click);
            // 
            // btnQtyLess
            // 
            this.btnQtyLess.BackColor = System.Drawing.Color.ForestGreen;
            this.btnQtyLess.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtyLess.Location = new System.Drawing.Point(870, 257);
            this.btnQtyLess.Name = "btnQtyLess";
            this.btnQtyLess.Size = new System.Drawing.Size(44, 56);
            this.btnQtyLess.TabIndex = 25;
            this.btnQtyLess.Text = "V";
            this.btnQtyLess.UseVisualStyleBackColor = false;
            this.btnQtyLess.Click += new System.EventHandler(this.btnQtyLess_Click);
            // 
            // btnHigh
            // 
            this.btnHigh.BackColor = System.Drawing.Color.ForestGreen;
            this.btnHigh.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHigh.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnHigh.Location = new System.Drawing.Point(981, 257);
            this.btnHigh.Name = "btnHigh";
            this.btnHigh.Size = new System.Drawing.Size(48, 56);
            this.btnHigh.TabIndex = 26;
            this.btnHigh.Text = "^";
            this.btnHigh.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnHigh.UseVisualStyleBackColor = false;
            this.btnHigh.Click += new System.EventHandler(this.btnHigh_Click);
            // 
            // btnSmall
            // 
            this.btnSmall.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSmall.Font = new System.Drawing.Font("Arial Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSmall.ForeColor = System.Drawing.Color.White;
            this.btnSmall.Location = new System.Drawing.Point(871, 343);
            this.btnSmall.Name = "btnSmall";
            this.btnSmall.Size = new System.Drawing.Size(52, 59);
            this.btnSmall.TabIndex = 28;
            this.btnSmall.Text = "S";
            this.btnSmall.UseVisualStyleBackColor = false;
            this.btnSmall.Click += new System.EventHandler(this.btnSmall_Click);
            // 
            // btnMedium
            // 
            this.btnMedium.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnMedium.Font = new System.Drawing.Font("Arial Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedium.ForeColor = System.Drawing.Color.White;
            this.btnMedium.Location = new System.Drawing.Point(922, 343);
            this.btnMedium.Name = "btnMedium";
            this.btnMedium.Size = new System.Drawing.Size(53, 59);
            this.btnMedium.TabIndex = 29;
            this.btnMedium.Text = "M";
            this.btnMedium.UseVisualStyleBackColor = false;
            this.btnMedium.Click += new System.EventHandler(this.btnMedium_Click);
            // 
            // btnLarge
            // 
            this.btnLarge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnLarge.Font = new System.Drawing.Font("Arial Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLarge.ForeColor = System.Drawing.Color.White;
            this.btnLarge.Location = new System.Drawing.Point(973, 343);
            this.btnLarge.Name = "btnLarge";
            this.btnLarge.Size = new System.Drawing.Size(56, 59);
            this.btnLarge.TabIndex = 30;
            this.btnLarge.Text = "L";
            this.btnLarge.UseVisualStyleBackColor = false;
            this.btnLarge.Click += new System.EventHandler(this.btnLarge_Click);
            // 
            // btnPearl
            // 
            this.btnPearl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnPearl.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPearl.ForeColor = System.Drawing.Color.White;
            this.btnPearl.Location = new System.Drawing.Point(870, 429);
            this.btnPearl.Name = "btnPearl";
            this.btnPearl.Size = new System.Drawing.Size(53, 57);
            this.btnPearl.TabIndex = 31;
            this.btnPearl.Text = "Pearl";
            this.btnPearl.UseVisualStyleBackColor = false;
            this.btnPearl.Click += new System.EventHandler(this.btnPearl_Click);
            // 
            // btnCrystal
            // 
            this.btnCrystal.BackColor = System.Drawing.Color.Silver;
            this.btnCrystal.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrystal.ForeColor = System.Drawing.Color.White;
            this.btnCrystal.Location = new System.Drawing.Point(921, 429);
            this.btnCrystal.Name = "btnCrystal";
            this.btnCrystal.Size = new System.Drawing.Size(54, 57);
            this.btnCrystal.TabIndex = 32;
            this.btnCrystal.Text = "Crystal";
            this.btnCrystal.UseVisualStyleBackColor = false;
            this.btnCrystal.Click += new System.EventHandler(this.btnCrystal_Click);
            // 
            // btnCreamCheese
            // 
            this.btnCreamCheese.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnCreamCheese.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreamCheese.ForeColor = System.Drawing.Color.White;
            this.btnCreamCheese.Location = new System.Drawing.Point(973, 429);
            this.btnCreamCheese.Name = "btnCreamCheese";
            this.btnCreamCheese.Size = new System.Drawing.Size(56, 57);
            this.btnCreamCheese.TabIndex = 33;
            this.btnCreamCheese.Text = "Cream Cheese";
            this.btnCreamCheese.UseVisualStyleBackColor = false;
            this.btnCreamCheese.Click += new System.EventHandler(this.btnCreamCheese_Click);
            // 
            // btnCoffeeJelly
            // 
            this.btnCoffeeJelly.BackColor = System.Drawing.Color.Green;
            this.btnCoffeeJelly.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoffeeJelly.ForeColor = System.Drawing.Color.White;
            this.btnCoffeeJelly.Location = new System.Drawing.Point(870, 483);
            this.btnCoffeeJelly.Name = "btnCoffeeJelly";
            this.btnCoffeeJelly.Size = new System.Drawing.Size(53, 56);
            this.btnCoffeeJelly.TabIndex = 34;
            this.btnCoffeeJelly.Text = "Coffee Jelly";
            this.btnCoffeeJelly.UseVisualStyleBackColor = false;
            this.btnCoffeeJelly.Click += new System.EventHandler(this.btnCoffeeJelly_Click);
            // 
            // btnCrushedOreo
            // 
            this.btnCrushedOreo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCrushedOreo.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrushedOreo.ForeColor = System.Drawing.Color.White;
            this.btnCrushedOreo.Location = new System.Drawing.Point(922, 483);
            this.btnCrushedOreo.Name = "btnCrushedOreo";
            this.btnCrushedOreo.Size = new System.Drawing.Size(53, 56);
            this.btnCrushedOreo.TabIndex = 35;
            this.btnCrushedOreo.Text = "Crushed Oreo";
            this.btnCrushedOreo.UseVisualStyleBackColor = false;
            this.btnCrushedOreo.Click += new System.EventHandler(this.btnCrushedOreo_Click);
            // 
            // btnCreamPuff
            // 
            this.btnCreamPuff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnCreamPuff.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreamPuff.ForeColor = System.Drawing.Color.White;
            this.btnCreamPuff.Location = new System.Drawing.Point(973, 483);
            this.btnCreamPuff.Name = "btnCreamPuff";
            this.btnCreamPuff.Size = new System.Drawing.Size(56, 56);
            this.btnCreamPuff.TabIndex = 36;
            this.btnCreamPuff.Text = "Cream Puff";
            this.btnCreamPuff.UseVisualStyleBackColor = false;
            this.btnCreamPuff.Click += new System.EventHandler(this.btnCreamPuff_Click);
            // 
            // btnCakeCheese
            // 
            this.btnCakeCheese.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnCakeCheese.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCakeCheese.ForeColor = System.Drawing.Color.White;
            this.btnCakeCheese.Location = new System.Drawing.Point(871, 537);
            this.btnCakeCheese.Name = "btnCakeCheese";
            this.btnCakeCheese.Size = new System.Drawing.Size(52, 53);
            this.btnCakeCheese.TabIndex = 37;
            this.btnCakeCheese.Text = "Cheese Cake";
            this.btnCakeCheese.UseVisualStyleBackColor = false;
            this.btnCakeCheese.Click += new System.EventHandler(this.btnCakeCheese_Click);
            // 
            // btnBlank1
            // 
            this.btnBlank1.BackColor = System.Drawing.Color.Purple;
            this.btnBlank1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBlank1.ForeColor = System.Drawing.Color.White;
            this.btnBlank1.Location = new System.Drawing.Point(922, 537);
            this.btnBlank1.Name = "btnBlank1";
            this.btnBlank1.Size = new System.Drawing.Size(53, 53);
            this.btnBlank1.TabIndex = 38;
            this.btnBlank1.UseVisualStyleBackColor = false;
            // 
            // btnBlank2
            // 
            this.btnBlank2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnBlank2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBlank2.ForeColor = System.Drawing.Color.White;
            this.btnBlank2.Location = new System.Drawing.Point(973, 537);
            this.btnBlank2.Name = "btnBlank2";
            this.btnBlank2.Size = new System.Drawing.Size(56, 53);
            this.btnBlank2.TabIndex = 39;
            this.btnBlank2.UseVisualStyleBackColor = false;
            // 
            // btn25
            // 
            this.btn25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn25.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn25.ForeColor = System.Drawing.Color.White;
            this.btn25.Location = new System.Drawing.Point(871, 623);
            this.btn25.Name = "btn25";
            this.btn25.Size = new System.Drawing.Size(41, 58);
            this.btn25.TabIndex = 40;
            this.btn25.Text = "25";
            this.btn25.UseVisualStyleBackColor = false;
            this.btn25.Click += new System.EventHandler(this.btn25_Click);
            // 
            // btn50
            // 
            this.btn50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn50.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn50.ForeColor = System.Drawing.Color.White;
            this.btn50.Location = new System.Drawing.Point(911, 623);
            this.btn50.Name = "btn50";
            this.btn50.Size = new System.Drawing.Size(39, 58);
            this.btn50.TabIndex = 41;
            this.btn50.Text = "50";
            this.btn50.UseVisualStyleBackColor = false;
            this.btn50.Click += new System.EventHandler(this.btn50_Click);
            // 
            // btn75
            // 
            this.btn75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn75.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn75.ForeColor = System.Drawing.Color.White;
            this.btn75.Location = new System.Drawing.Point(949, 623);
            this.btn75.Name = "btn75";
            this.btn75.Size = new System.Drawing.Size(40, 58);
            this.btn75.TabIndex = 42;
            this.btn75.Text = "75";
            this.btn75.UseVisualStyleBackColor = false;
            this.btn75.Click += new System.EventHandler(this.btn75_Click);
            // 
            // btn100
            // 
            this.btn100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn100.Font = new System.Drawing.Font("Arial Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn100.ForeColor = System.Drawing.Color.White;
            this.btn100.Location = new System.Drawing.Point(988, 623);
            this.btn100.Name = "btn100";
            this.btn100.Size = new System.Drawing.Size(41, 58);
            this.btn100.TabIndex = 43;
            this.btn100.Text = "100";
            this.btn100.UseVisualStyleBackColor = false;
            this.btn100.Click += new System.EventHandler(this.btn100_Click);
            // 
            // panel6
            // 
            this.panel6.AutoScroll = true;
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel6.Controls.Add(this.btnDelete1);
            this.panel6.Controls.Add(this.lblItem1);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Location = new System.Drawing.Point(1047, 220);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(228, 403);
            this.panel6.TabIndex = 46;
            // 
            // btnDelete1
            // 
            this.btnDelete1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDelete1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete1.Location = new System.Drawing.Point(185, 52);
            this.btnDelete1.Name = "btnDelete1";
            this.btnDelete1.Size = new System.Drawing.Size(22, 484);
            this.btnDelete1.TabIndex = 9;
            this.btnDelete1.Text = "D  E  L  E  T  E";
            this.btnDelete1.UseVisualStyleBackColor = false;
            this.btnDelete1.Click += new System.EventHandler(this.btnDelete1_Click);
            // 
            // lblItem1
            // 
            this.lblItem1.BackColor = System.Drawing.Color.White;
            this.lblItem1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem1.Location = new System.Drawing.Point(7, 52);
            this.lblItem1.Name = "lblItem1";
            this.lblItem1.Size = new System.Drawing.Size(201, 484);
            this.lblItem1.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label3.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(174, 24);
            this.label3.TabIndex = 7;
            this.label3.Text = "ITEM SUMMARY:";
            // 
            // btnProceedPayment1
            // 
            this.btnProceedPayment1.BackColor = System.Drawing.Color.ForestGreen;
            this.btnProceedPayment1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProceedPayment1.ForeColor = System.Drawing.Color.White;
            this.btnProceedPayment1.Location = new System.Drawing.Point(1047, 766);
            this.btnProceedPayment1.Name = "btnProceedPayment1";
            this.btnProceedPayment1.Size = new System.Drawing.Size(229, 62);
            this.btnProceedPayment1.TabIndex = 48;
            this.btnProceedPayment1.Text = "Proceed Payment";
            this.btnProceedPayment1.UseVisualStyleBackColor = false;
            this.btnProceedPayment1.Click += new System.EventHandler(this.btnProceedPayment1_Click);
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerName.Location = new System.Drawing.Point(305, 775);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(531, 29);
            this.txtCustomerName.TabIndex = 49;
            // 
            // btnConfirm1
            // 
            this.btnConfirm1.BackColor = System.Drawing.Color.ForestGreen;
            this.btnConfirm1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm1.ForeColor = System.Drawing.Color.White;
            this.btnConfirm1.Location = new System.Drawing.Point(871, 684);
            this.btnConfirm1.Name = "btnConfirm1";
            this.btnConfirm1.Size = new System.Drawing.Size(158, 41);
            this.btnConfirm1.TabIndex = 44;
            this.btnConfirm1.Text = "Confirm";
            this.btnConfirm1.UseVisualStyleBackColor = false;
            this.btnConfirm1.Click += new System.EventHandler(this.btnConfirm1_Click);
            // 
            // btnCancel1
            // 
            this.btnCancel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCancel1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel1.ForeColor = System.Drawing.Color.White;
            this.btnCancel1.Location = new System.Drawing.Point(871, 726);
            this.btnCancel1.Name = "btnCancel1";
            this.btnCancel1.Size = new System.Drawing.Size(158, 25);
            this.btnCancel1.TabIndex = 45;
            this.btnCancel1.Text = "Cancel";
            this.btnCancel1.UseVisualStyleBackColor = false;
            this.btnCancel1.Click += new System.EventHandler(this.btnCancel1_Click);
            // 
            // lblQty
            // 
            this.lblQty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lblQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty.Location = new System.Drawing.Point(913, 259);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(68, 52);
            this.lblQty.TabIndex = 50;
            this.lblQty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSummary
            // 
            this.lblSummary.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lblSummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSummary.Location = new System.Drawing.Point(1047, 629);
            this.lblSummary.Name = "lblSummary";
            this.lblSummary.Size = new System.Drawing.Size(228, 125);
            this.lblSummary.TabIndex = 51;
            // 
            // btnPOS
            // 
            this.btnPOS.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPOS.BackgroundImage")));
            this.btnPOS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPOS.Location = new System.Drawing.Point(0, 85);
            this.btnPOS.Name = "btnPOS";
            this.btnPOS.Size = new System.Drawing.Size(100, 129);
            this.btnPOS.TabIndex = 52;
            this.btnPOS.UseVisualStyleBackColor = true;
            this.btnPOS.Click += new System.EventHandler(this.btnPOS_Click_1);
            // 
            // btnIMS
            // 
            this.btnIMS.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnIMS.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnIMS.BackgroundImage")));
            this.btnIMS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnIMS.Location = new System.Drawing.Point(0, 213);
            this.btnIMS.Name = "btnIMS";
            this.btnIMS.Size = new System.Drawing.Size(100, 130);
            this.btnIMS.TabIndex = 53;
            this.btnIMS.UseVisualStyleBackColor = true;
            this.btnIMS.Click += new System.EventHandler(this.btnIMS_Click);
            // 
            // btnCUS
            // 
            this.btnCUS.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCUS.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCUS.BackgroundImage")));
            this.btnCUS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCUS.Location = new System.Drawing.Point(0, 342);
            this.btnCUS.Name = "btnCUS";
            this.btnCUS.Size = new System.Drawing.Size(100, 130);
            this.btnCUS.TabIndex = 54;
            this.btnCUS.UseVisualStyleBackColor = true;
            // 
            // btnREP
            // 
            this.btnREP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnREP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnREP.BackgroundImage")));
            this.btnREP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnREP.Location = new System.Drawing.Point(0, 471);
            this.btnREP.Name = "btnREP";
            this.btnREP.Size = new System.Drawing.Size(100, 130);
            this.btnREP.TabIndex = 55;
            this.btnREP.UseVisualStyleBackColor = true;
            // 
            // btnADM
            // 
            this.btnADM.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnADM.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnADM.BackgroundImage")));
            this.btnADM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnADM.Location = new System.Drawing.Point(0, 599);
            this.btnADM.Name = "btnADM";
            this.btnADM.Size = new System.Drawing.Size(100, 130);
            this.btnADM.TabIndex = 54;
            this.btnADM.UseVisualStyleBackColor = true;
            this.btnADM.Click += new System.EventHandler(this.btnADM_Click);
            // 
            // btnSET
            // 
            this.btnSET.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSET.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSET.BackgroundImage")));
            this.btnSET.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSET.Location = new System.Drawing.Point(0, 726);
            this.btnSET.Name = "btnSET";
            this.btnSET.Size = new System.Drawing.Size(100, 126);
            this.btnSET.TabIndex = 56;
            this.btnSET.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnCancelPayment);
            this.panel7.Controls.Add(this.btnCashless);
            this.panel7.Controls.Add(this.btnCash);
            this.panel7.Controls.Add(this.label4);
            this.panel7.Location = new System.Drawing.Point(1047, 219);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(228, 609);
            this.panel7.TabIndex = 57;
            // 
            // btnCancelPayment
            // 
            this.btnCancelPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCancelPayment.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelPayment.ForeColor = System.Drawing.Color.White;
            this.btnCancelPayment.Location = new System.Drawing.Point(19, 547);
            this.btnCancelPayment.Name = "btnCancelPayment";
            this.btnCancelPayment.Size = new System.Drawing.Size(189, 47);
            this.btnCancelPayment.TabIndex = 3;
            this.btnCancelPayment.Text = "Cancel Payment";
            this.btnCancelPayment.UseVisualStyleBackColor = false;
            this.btnCancelPayment.Click += new System.EventHandler(this.btnCancelPayment_Click);
            // 
            // btnCashless
            // 
            this.btnCashless.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCashless.Font = new System.Drawing.Font("Arial Black", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCashless.ForeColor = System.Drawing.Color.White;
            this.btnCashless.Location = new System.Drawing.Point(18, 306);
            this.btnCashless.Name = "btnCashless";
            this.btnCashless.Size = new System.Drawing.Size(190, 200);
            this.btnCashless.TabIndex = 2;
            this.btnCashless.Text = "CASHLESS";
            this.btnCashless.UseVisualStyleBackColor = false;
            this.btnCashless.Click += new System.EventHandler(this.btnCashless_Click);
            // 
            // btnCash
            // 
            this.btnCash.BackColor = System.Drawing.Color.ForestGreen;
            this.btnCash.Font = new System.Drawing.Font("Arial Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCash.ForeColor = System.Drawing.Color.White;
            this.btnCash.Location = new System.Drawing.Point(15, 66);
            this.btnCash.Name = "btnCash";
            this.btnCash.Size = new System.Drawing.Size(193, 200);
            this.btnCash.TabIndex = 1;
            this.btnCash.Text = "CASH";
            this.btnCash.UseVisualStyleBackColor = false;
            this.btnCash.Click += new System.EventHandler(this.btnCash_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(9, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(211, 24);
            this.label4.TabIndex = 0;
            this.label4.Text = "PAYMENT OPTIONS:";
            // 
            // panel8
            // 
            this.panel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel8.BackgroundImage")));
            this.panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel8.Controls.Add(this.btnConfirmPayment4);
            this.panel8.Controls.Add(this.pictureBox1);
            this.panel8.Controls.Add(this.btnCancel2);
            this.panel8.Controls.Add(this.btnConfirm2);
            this.panel8.Controls.Add(this.txtExactAmount);
            this.panel8.Controls.Add(this.btn1000Pesos);
            this.panel8.Controls.Add(this.btn500Pesos);
            this.panel8.Controls.Add(this.btn200Pesos);
            this.panel8.Controls.Add(this.btn100Pesos);
            this.panel8.Location = new System.Drawing.Point(1047, 218);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(228, 610);
            this.panel8.TabIndex = 58;
            // 
            // btnConfirmPayment4
            // 
            this.btnConfirmPayment4.BackColor = System.Drawing.Color.ForestGreen;
            this.btnConfirmPayment4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmPayment4.ForeColor = System.Drawing.Color.White;
            this.btnConfirmPayment4.Location = new System.Drawing.Point(5, 491);
            this.btnConfirmPayment4.Name = "btnConfirmPayment4";
            this.btnConfirmPayment4.Size = new System.Drawing.Size(217, 50);
            this.btnConfirmPayment4.TabIndex = 8;
            this.btnConfirmPayment4.Text = "Confirm Payment";
            this.btnConfirmPayment4.UseVisualStyleBackColor = false;
            this.btnConfirmPayment4.Click += new System.EventHandler(this.btnConfirmPayment4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(17, 328);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(36, 44);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // btnCancel2
            // 
            this.btnCancel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCancel2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel2.ForeColor = System.Drawing.Color.White;
            this.btnCancel2.Location = new System.Drawing.Point(0, 550);
            this.btnCancel2.Name = "btnCancel2";
            this.btnCancel2.Size = new System.Drawing.Size(227, 57);
            this.btnCancel2.TabIndex = 6;
            this.btnCancel2.Text = "Cancel Payment";
            this.btnCancel2.UseVisualStyleBackColor = false;
            this.btnCancel2.Click += new System.EventHandler(this.btnCancel2_Click);
            // 
            // btnConfirm2
            // 
            this.btnConfirm2.AutoEllipsis = true;
            this.btnConfirm2.BackColor = System.Drawing.Color.ForestGreen;
            this.btnConfirm2.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm2.ForeColor = System.Drawing.Color.White;
            this.btnConfirm2.Location = new System.Drawing.Point(13, 395);
            this.btnConfirm2.Name = "btnConfirm2";
            this.btnConfirm2.Size = new System.Drawing.Size(196, 92);
            this.btnConfirm2.TabIndex = 5;
            this.btnConfirm2.Text = "Confirm Amount";
            this.btnConfirm2.UseVisualStyleBackColor = false;
            this.btnConfirm2.Click += new System.EventHandler(this.btnConfirm2_Click);
            // 
            // txtExactAmount
            // 
            this.txtExactAmount.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExactAmount.Location = new System.Drawing.Point(47, 328);
            this.txtExactAmount.Name = "txtExactAmount";
            this.txtExactAmount.Size = new System.Drawing.Size(161, 44);
            this.txtExactAmount.TabIndex = 4;
            // 
            // btn1000Pesos
            // 
            this.btn1000Pesos.BackColor = System.Drawing.Color.ForestGreen;
            this.btn1000Pesos.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1000Pesos.ForeColor = System.Drawing.Color.White;
            this.btn1000Pesos.Location = new System.Drawing.Point(15, 255);
            this.btn1000Pesos.Name = "btn1000Pesos";
            this.btn1000Pesos.Size = new System.Drawing.Size(194, 44);
            this.btn1000Pesos.TabIndex = 3;
            this.btn1000Pesos.Text = "₱ 1,000.00";
            this.btn1000Pesos.UseVisualStyleBackColor = false;
            this.btn1000Pesos.Click += new System.EventHandler(this.btn1000Pesos_Click);
            // 
            // btn500Pesos
            // 
            this.btn500Pesos.BackColor = System.Drawing.Color.ForestGreen;
            this.btn500Pesos.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn500Pesos.ForeColor = System.Drawing.Color.White;
            this.btn500Pesos.Location = new System.Drawing.Point(16, 201);
            this.btn500Pesos.Name = "btn500Pesos";
            this.btn500Pesos.Size = new System.Drawing.Size(193, 44);
            this.btn500Pesos.TabIndex = 2;
            this.btn500Pesos.Text = "₱ 500.00";
            this.btn500Pesos.UseVisualStyleBackColor = false;
            this.btn500Pesos.Click += new System.EventHandler(this.btn500Pesos_Click);
            // 
            // btn200Pesos
            // 
            this.btn200Pesos.BackColor = System.Drawing.Color.ForestGreen;
            this.btn200Pesos.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn200Pesos.ForeColor = System.Drawing.Color.White;
            this.btn200Pesos.Location = new System.Drawing.Point(16, 149);
            this.btn200Pesos.Name = "btn200Pesos";
            this.btn200Pesos.Size = new System.Drawing.Size(193, 44);
            this.btn200Pesos.TabIndex = 1;
            this.btn200Pesos.Text = "₱ 200.00";
            this.btn200Pesos.UseVisualStyleBackColor = false;
            this.btn200Pesos.Click += new System.EventHandler(this.btn200Pesos_Click);
            // 
            // btn100Pesos
            // 
            this.btn100Pesos.BackColor = System.Drawing.Color.ForestGreen;
            this.btn100Pesos.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn100Pesos.ForeColor = System.Drawing.Color.White;
            this.btn100Pesos.Location = new System.Drawing.Point(16, 95);
            this.btn100Pesos.Name = "btn100Pesos";
            this.btn100Pesos.Size = new System.Drawing.Size(193, 44);
            this.btn100Pesos.TabIndex = 0;
            this.btn100Pesos.Text = "₱ 100.00";
            this.btn100Pesos.UseVisualStyleBackColor = false;
            this.btn100Pesos.Click += new System.EventHandler(this.btn100Pesos_Click);
            // 
            // panel9
            // 
            this.panel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel9.BackgroundImage")));
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel9.Controls.Add(this.btnCancelPayment3);
            this.panel9.Controls.Add(this.button2);
            this.panel9.Controls.Add(this.btnMasterCard);
            this.panel9.Controls.Add(this.btnPaypal);
            this.panel9.Controls.Add(this.btnPaymaya);
            this.panel9.Controls.Add(this.btnGcash);
            this.panel9.Location = new System.Drawing.Point(1047, 218);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(229, 610);
            this.panel9.TabIndex = 61;
            // 
            // btnCancelPayment3
            // 
            this.btnCancelPayment3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCancelPayment3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelPayment3.ForeColor = System.Drawing.Color.White;
            this.btnCancelPayment3.Location = new System.Drawing.Point(0, 550);
            this.btnCancelPayment3.Name = "btnCancelPayment3";
            this.btnCancelPayment3.Size = new System.Drawing.Size(228, 59);
            this.btnCancelPayment3.TabIndex = 5;
            this.btnCancelPayment3.Text = "Cancel Payment";
            this.btnCancelPayment3.UseVisualStyleBackColor = false;
            this.btnCancelPayment3.Click += new System.EventHandler(this.btnCancelPayment3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Location = new System.Drawing.Point(17, 418);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(194, 69);
            this.button2.TabIndex = 4;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // btnMasterCard
            // 
            this.btnMasterCard.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMasterCard.BackgroundImage")));
            this.btnMasterCard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMasterCard.Location = new System.Drawing.Point(17, 339);
            this.btnMasterCard.Name = "btnMasterCard";
            this.btnMasterCard.Size = new System.Drawing.Size(193, 69);
            this.btnMasterCard.TabIndex = 3;
            this.btnMasterCard.UseVisualStyleBackColor = true;
            this.btnMasterCard.Click += new System.EventHandler(this.btnMasterCard_Click);
            // 
            // btnPaypal
            // 
            this.btnPaypal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPaypal.BackgroundImage")));
            this.btnPaypal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPaypal.Location = new System.Drawing.Point(16, 258);
            this.btnPaypal.Name = "btnPaypal";
            this.btnPaypal.Size = new System.Drawing.Size(194, 69);
            this.btnPaypal.TabIndex = 2;
            this.btnPaypal.UseVisualStyleBackColor = true;
            this.btnPaypal.Click += new System.EventHandler(this.btnPaypal_Click);
            // 
            // btnPaymaya
            // 
            this.btnPaymaya.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPaymaya.BackgroundImage")));
            this.btnPaymaya.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPaymaya.Location = new System.Drawing.Point(16, 180);
            this.btnPaymaya.Name = "btnPaymaya";
            this.btnPaymaya.Size = new System.Drawing.Size(194, 69);
            this.btnPaymaya.TabIndex = 1;
            this.btnPaymaya.UseVisualStyleBackColor = true;
            this.btnPaymaya.Click += new System.EventHandler(this.btnPaymaya_Click);
            // 
            // btnGcash
            // 
            this.btnGcash.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGcash.BackgroundImage")));
            this.btnGcash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGcash.Location = new System.Drawing.Point(14, 95);
            this.btnGcash.Name = "btnGcash";
            this.btnGcash.Size = new System.Drawing.Size(197, 69);
            this.btnGcash.TabIndex = 0;
            this.btnGcash.UseVisualStyleBackColor = true;
            this.btnGcash.Click += new System.EventHandler(this.btnGcash_Click);
            // 
            // label5
            // 
            this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
            this.label5.Location = new System.Drawing.Point(490, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(446, 56);
            this.label5.TabIndex = 62;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(867, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(408, 47);
            this.label6.TabIndex = 63;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(891, 171);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 32);
            this.button1.TabIndex = 64;
            this.button1.Text = "Dine In";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(1094, 171);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(159, 32);
            this.button3.TabIndex = 65;
            this.button3.Text = "Take out";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // AdminPanel
            // 
            this.AdminPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("AdminPanel.BackgroundImage")));
            this.AdminPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.AdminPanel.Controls.Add(this.label7);
            this.AdminPanel.Controls.Add(this.button6);
            this.AdminPanel.Controls.Add(this.button5);
            this.AdminPanel.Controls.Add(this.button4);
            this.AdminPanel.Location = new System.Drawing.Point(97, 85);
            this.AdminPanel.Name = "AdminPanel";
            this.AdminPanel.Size = new System.Drawing.Size(1240, 767);
            this.AdminPanel.TabIndex = 66;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(279, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(264, 78);
            this.label7.TabIndex = 3;
            // 
            // button6
            // 
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.Location = new System.Drawing.Point(877, 126);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(267, 130);
            this.button6.TabIndex = 2;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Location = new System.Drawing.Point(590, 125);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(275, 132);
            this.button5.TabIndex = 1;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Location = new System.Drawing.Point(309, 124);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(267, 134);
            this.button4.TabIndex = 0;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // POS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = global::POSSystem.Properties.Resources.Point_of_Sale___Milk_Tea;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1336, 881);
            this.Controls.Add(this.AdminPanel);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.btnSET);
            this.Controls.Add(this.btnADM);
            this.Controls.Add(this.btnREP);
            this.Controls.Add(this.btnCUS);
            this.Controls.Add(this.btnIMS);
            this.Controls.Add(this.btnPOS);
            this.Controls.Add(this.lblSummary);
            this.Controls.Add(this.lblQty);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnProceedPayment1);
            this.Controls.Add(this.btnCancel1);
            this.Controls.Add(this.btnConfirm1);
            this.Controls.Add(this.btn100);
            this.Controls.Add(this.btn75);
            this.Controls.Add(this.btn50);
            this.Controls.Add(this.btn25);
            this.Controls.Add(this.btnBlank2);
            this.Controls.Add(this.btnBlank1);
            this.Controls.Add(this.btnCakeCheese);
            this.Controls.Add(this.btnCreamPuff);
            this.Controls.Add(this.btnCrushedOreo);
            this.Controls.Add(this.btnCoffeeJelly);
            this.Controls.Add(this.btnCreamCheese);
            this.Controls.Add(this.btnCrystal);
            this.Controls.Add(this.btnPearl);
            this.Controls.Add(this.btnLarge);
            this.Controls.Add(this.btnMedium);
            this.Controls.Add(this.btnSmall);
            this.Controls.Add(this.btnHigh);
            this.Controls.Add(this.btnQtyLess);
            this.Controls.Add(this.btnHotBrew);
            this.Controls.Add(this.btnPraf);
            this.Controls.Add(this.btnFruitTea);
            this.Controls.Add(this.btnIcedCoffee);
            this.Controls.Add(this.btnMinimize);
            this.Controls.Add(this.btnMaximize);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.btnMilkTea);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "POS";
            this.Text = "Confirm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel9.ResumeLayout(false);
            this.AdminPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOkinawa;
        private System.Windows.Forms.Button btnDoubleDutch;
        private System.Windows.Forms.Button btnTaro;
        private System.Windows.Forms.Button btnIcedEarlGray;
        private System.Windows.Forms.Button btnWintermelon;
        private System.Windows.Forms.Button btnRedVelvet;
        private System.Windows.Forms.Button btnMatcha;
        private System.Windows.Forms.Button btnDarkChoco;
        private System.Windows.Forms.Button btnChocoKisses;
        private System.Windows.Forms.Button btnCheeseCake;
        private System.Windows.Forms.Button btnHoneyDue;
        private System.Windows.Forms.Button btnBrownSugar;
        private System.Windows.Forms.Button btnStrawberry;
        private System.Windows.Forms.Button btnLychee;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnJasmine;
        private System.Windows.Forms.Button btnAlmond;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnMilkTea;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnIcedCoffee;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnKapeBrusko;
        private System.Windows.Forms.Button btnChaiLatte;
        private System.Windows.Forms.Button btnLavender;
        private System.Windows.Forms.Button btnCaramel;
        private System.Windows.Forms.Button btnHazelnut;
        private System.Windows.Forms.Button btnVanilla;
        private System.Windows.Forms.Button btnMoca;
        private System.Windows.Forms.Button btnMacch;
        private System.Windows.Forms.Button btnIrish;
        private System.Windows.Forms.Button btnPumpkin;
        private System.Windows.Forms.Button btnAlmondMilk;
        private System.Windows.Forms.Button btnMatchaLatte;
        private System.Windows.Forms.Button btnChocoMint;
        private System.Windows.Forms.Button btnPeanut;
        private System.Windows.Forms.Button btnMaple;
        private System.Windows.Forms.Button btnCoconut;
        private System.Windows.Forms.Button btnFruitTea;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnCoconutTea;
        private System.Windows.Forms.Button btnHoneyDew;
        private System.Windows.Forms.Button btnPomegranate;
        private System.Windows.Forms.Button btnDragonFruit;
        private System.Windows.Forms.Button btnLycheeTea;
        private System.Windows.Forms.Button btnApple;
        private System.Windows.Forms.Button btnCherry;
        private System.Windows.Forms.Button btnPineappleTea;
        private System.Windows.Forms.Button btnBlueberry;
        private System.Windows.Forms.Button btnLemonTea;
        private System.Windows.Forms.Button btnStrawberryTea;
        private System.Windows.Forms.Button btnMango;
        private System.Windows.Forms.Button btnCranberry;
        private System.Windows.Forms.Button btnGrapefruit;
        private System.Windows.Forms.Button btnWatermelonTea;
        private System.Windows.Forms.Button btnPeach;
        private System.Windows.Forms.Button btnPraf;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnVanillaFrappe;
        private System.Windows.Forms.Button btnCaramelFrappe;
        private System.Windows.Forms.Button btnMochaFrappe;
        private System.Windows.Forms.Button btnClassicCofee;
        private System.Windows.Forms.Button btnMachaGreenTea;
        private System.Windows.Forms.Button btnChaiLatteFrappe;
        private System.Windows.Forms.Button btnRedVelvetFrappe;
        private System.Windows.Forms.Button btnBananaMochaFrappe;
        private System.Windows.Forms.Button btnStrawberryFrappe;
        private System.Windows.Forms.Button btnPumpkinSpice;
        private System.Windows.Forms.Button btnToffeeNut;
        private System.Windows.Forms.Button btnPeanutButterFrappe;
        private System.Windows.Forms.Button btnCookiesAndCream;
        private System.Windows.Forms.Button btnChocoloateFrappe;
        private System.Windows.Forms.Button btnCoconutFrappe;
        private System.Windows.Forms.Button btnHazelnutFrappe;
        private System.Windows.Forms.Button btnHotBrew;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnGingerbreadLatte;
        private System.Windows.Forms.Button btnSaltedCaramelLatte;
        private System.Windows.Forms.Button btnHoneyAlmondLatte;
        private System.Windows.Forms.Button btnToastedMarshmallow;
        private System.Windows.Forms.Button btnCinnamonDolceLatte;
        private System.Windows.Forms.Button btnHazelnutHotBrew;
        private System.Windows.Forms.Button btnLavenderLatteHot;
        private System.Windows.Forms.Button btnBrownSugarOathMilk;
        private System.Windows.Forms.Button btnMaplePecanLatte;
        private System.Windows.Forms.Button btnCaramelMacchiato;
        private System.Windows.Forms.Button btnClassicMocha;
        private System.Windows.Forms.Button btnChaiLatteHot;
        private System.Windows.Forms.Button btnIrishCreamLatte;
        private System.Windows.Forms.Button btnCoconutMochaLatte;
        private System.Windows.Forms.Button btnAlmondJoy;
        private System.Windows.Forms.Button btnMexicanMocha;
        private System.Windows.Forms.Button btnQtyLess;
        private System.Windows.Forms.Button btnHigh;
        private System.Windows.Forms.Button btnSmall;
        private System.Windows.Forms.Button btnMedium;
        private System.Windows.Forms.Button btnLarge;
        private System.Windows.Forms.Button btnPearl;
        private System.Windows.Forms.Button btnCrystal;
        private System.Windows.Forms.Button btnCreamCheese;
        private System.Windows.Forms.Button btnCoffeeJelly;
        private System.Windows.Forms.Button btnCrushedOreo;
        private System.Windows.Forms.Button btnCreamPuff;
        private System.Windows.Forms.Button btnCakeCheese;
        private System.Windows.Forms.Button btnBlank1;
        private System.Windows.Forms.Button btnBlank2;
        private System.Windows.Forms.Button btn25;
        private System.Windows.Forms.Button btn50;
        private System.Windows.Forms.Button btn75;
        private System.Windows.Forms.Button btn100;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnProceedPayment1;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Button btnConfirm1;
        private System.Windows.Forms.Button btnCancel1;
        private System.Windows.Forms.Button btnDelete1;
        private System.Windows.Forms.Label lblItem1;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.Label lblSummary;
        private System.Windows.Forms.Button btnPOS;
        private System.Windows.Forms.Button btnADM;
        private System.Windows.Forms.Button btnIMS;
        private System.Windows.Forms.Button btnCUS;
        private System.Windows.Forms.Button btnREP;
        private System.Windows.Forms.Button btnSET;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCashless;
        private System.Windows.Forms.Button btnCash;
        private System.Windows.Forms.Button btnCancelPayment;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btn100Pesos;
        private System.Windows.Forms.Button btn500Pesos;
        private System.Windows.Forms.Button btn200Pesos;
        private System.Windows.Forms.Button btn1000Pesos;
        private System.Windows.Forms.Button btnConfirm2;
        private System.Windows.Forms.TextBox txtExactAmount;
        private System.Windows.Forms.Button btnCancel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btnPaypal;
        private System.Windows.Forms.Button btnPaymaya;
        private System.Windows.Forms.Button btnGcash;
        private System.Windows.Forms.Button btnCancelPayment3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnMasterCard;
        private System.Windows.Forms.Button btnConfirmPayment4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel AdminPanel;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label7;
    }
}

